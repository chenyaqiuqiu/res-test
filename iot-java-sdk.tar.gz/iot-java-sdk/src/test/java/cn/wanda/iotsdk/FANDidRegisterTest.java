package cn.wanda.iotsdk;


import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class FANDidRegisterTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */

    private static void setLoggerProperty() {
        Properties prop = new Properties();
        prop.setProperty("log4j.rootLogger", "DEBUG, syslog, console");
        prop.setProperty("log4j.appender.syslog", "org.apache.log4j.net.SyslogAppender");
        prop.setProperty("log4j.appender.syslog.SyslogHost", "127.0.0.1");
        prop.setProperty("log4j.appender.syslog.Facility", "user");
        prop.setProperty("log4j.appender.syslog.layout", "org.apache.log4j.PatternLayout");
        prop.setProperty("log4j.appender.syslog.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
        
        prop.setProperty("log4j.appender.console", "org.apache.log4j.ConsoleAppender");
        prop.setProperty("log4j.appender.console.Target", "System.out");
        prop.setProperty("log4j.appender.console.layout", "org.apache.log4j.PatternLayout");
        prop.setProperty("log4j.appender.console.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
        
        PropertyConfigurator.configure(prop);
        Logger logger = Logger.getLogger(FANDidRegisterTest.class);  
        logger.setLevel(Level.DEBUG);
    }


    FANDidRegister didRegister;
    public FANDidRegisterTest()
    {
        setLoggerProperty();
        String pk = "81b05fb98533429a844abc0484b49083";
        String pk_secret = "bc1fe7fdf4d248329b08d94cc9173f73";
        String mac = "000000000012";
        String url = "iotopenapi.uat.ffan.com";

        didRegister = new FANDidRegister(pk, pk_secret, mac, url);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( FANDidRegisterTest.class );
    }

    /**
     * Rigourous Test :-)
     */

    
    public void testRegister()
    {
        //didRegister.register();
        //String did = didRegister.getDid();
        //assertTrue( did != null && did.length() > 0 );
    }

    public void testProvision()
    {
        //didRegister.register();
        //String did = didRegister.getDid();
        //didRegister.provision();
        //String mqttUrl = didRegister.getMqttUrl();
        //assertTrue( mqttUrl != null && mqttUrl.length() > 0 );

        //String mqttPort = didRegister.getMqttPort();
        //assertTrue( mqttPort != null && mqttPort.length() > 0 );
    }
}