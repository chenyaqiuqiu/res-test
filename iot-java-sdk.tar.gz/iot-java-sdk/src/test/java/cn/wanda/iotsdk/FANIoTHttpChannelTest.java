package cn.wanda.iotsdk;

import java.io.File;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.json.JSONObject;

/**
 * Unit test for simple App.
 */
public class FANIoTHttpChannelTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */

    private static void setLoggerProperty() {
        Properties prop = new Properties();
        prop.setProperty("log4j.rootLogger", "DEBUG, syslog, console");
        prop.setProperty("log4j.appender.syslog", "org.apache.log4j.net.SyslogAppender");
        prop.setProperty("log4j.appender.syslog.SyslogHost", "127.0.0.1");
        prop.setProperty("log4j.appender.syslog.Facility", "user");
        prop.setProperty("log4j.appender.syslog.layout", "org.apache.log4j.PatternLayout");
        prop.setProperty("log4j.appender.syslog.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
        
        prop.setProperty("log4j.appender.console", "org.apache.log4j.ConsoleAppender");
        prop.setProperty("log4j.appender.console.Target", "System.out");
        prop.setProperty("log4j.appender.console.layout", "org.apache.log4j.PatternLayout");
        prop.setProperty("log4j.appender.console.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
        
        PropertyConfigurator.configure(prop);
        Logger logger = Logger.getLogger(FANIoTHttpChannelTest.class);  
        logger.setLevel(Level.DEBUG);
    }

    public FANIoTHttpChannelTest()
    {
        setLoggerProperty();
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( FANIoTHttpChannelTest.class );
    }

    /**
     * Rigourous Test :-)
     */

    
    public void testPostJson()
    {
        System.out.println(" test Post Json ");

        String testStr = "abcdefg";
        FANIoTHttpChannel httpClient = FANIoTHttpChannel.getInstance();

        //File testFile = new File("/home/chenyma/Downloads/node-v8.7.0-linux-x64.tar.xz");
        //httpClient.reportUserFile("http://127.0.0.1:8081", "v1", testStr.getBytes(), null);
        //httpClient.reportUserFile("http://127.0.0.1:8081", "v1", testFile, null);
    }

    public void testProvision()
    {
        System.out.println("test Post Binary");
    }
}