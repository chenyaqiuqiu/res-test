package cn.wanda.iotsdk;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class ConfigUtilTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public ConfigUtilTest()
    {
        ConfigUtil.loadConfig();
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( ConfigUtilTest.class );
    }

    /**
     * Rigourous Test :-)
     */

    public void testCheckExistKey()
    {
        assertTrue( ConfigUtil.checkExistKey("pk") );
        assertTrue( ConfigUtil.checkExistKey("pk_secret") );
        assertTrue( ConfigUtil.checkExistKey("hw_version") );
        assertTrue( ConfigUtil.checkExistKey("sw_version") );
        assertTrue( ConfigUtil.checkExistKey("dataPointsPath") );
        assertTrue( !ConfigUtil.checkExistKey("mmmm") );
    }

    public void testGetProperty()
    {
        assertEquals( ConfigUtil.getProperty("hw_version"),  "00MX3162");
    }

    public void testSetProperty()
    {
        ConfigUtil.setProperty("hw_version",  "0000001");
        assertEquals( ConfigUtil.getProperty("hw_version"),  "0000001");
        ConfigUtil.setProperty("hw_version",  "00MX3162");
        assertEquals( ConfigUtil.getProperty("hw_version"),  "00MX3162");
    }

    public void testRemoveKey()
    {
        ConfigUtil.removeKey("hw_version");
        assertTrue( !ConfigUtil.checkExistKey("hw_version"));
        ConfigUtil.setProperty("hw_version",  "00MX3162");
        assertEquals( ConfigUtil.getProperty("hw_version"),  "00MX3162");
    }
}
