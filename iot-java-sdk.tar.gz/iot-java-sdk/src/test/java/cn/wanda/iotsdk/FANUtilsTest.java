package cn.wanda.iotsdk;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class FANUtilsTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public FANUtilsTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( FANUtilsTest.class );
    }

    /**
     * Rigourous Test :-)
     */

    private void compareStr(String str) {
        byte[] uncompressData = new byte[1024];

        try{
            byte[] compressData = FANUtils.compressWithOpt(str.getBytes());
            uncompressData = FANUtils.uncompressWithOpt(compressData);            
        } catch (Exception e) {
                //
        } finally {
        }

        assertEquals( str, new String(uncompressData) );  
    }

    public void testCompressShortString()
    {
        compareStr("abc");
        compareStr("12345");
        compareStr("123456789012345678901234567890");
    }

    public void testCompressLongString()
    {
        compareStr("!^&*%$^@&*%&@()^@&($^&(FYU@TUIFG");
        compareStr("123456789012345678901234567890");
        compareStr("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        compareStr("dafdfadfadklafdaouifhdaakfhdjakfhdsuafidhaufidahfu2iqrbejkfbdjkavhduiqrhbfdjkaflhdjka" + 
                "flhdjafkdhajkfdhajkfbdjkabdjfkldhfdajfkdhafuiewqfuidabfvjdkalhjdfkafh8uqrph3891-24y389rhjfndjakpfdhaiufoye8q9fhdejafdjkafhdaifp48q9fbhdsjkafbdjakfhdsjk");
    }
}
