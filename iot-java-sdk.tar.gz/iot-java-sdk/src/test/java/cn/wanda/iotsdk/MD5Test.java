package cn.wanda.iotsdk;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.security.NoSuchAlgorithmException;

/**
 * Unit test for simple App.
 */
public class MD5Test 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public MD5Test( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( MD5Test.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testMD5()
    {
        String str = "";

        try {
            String testStr = "1234567890";
            str = StringMD5.getMD5(testStr).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
            System.out.println(ex.toString());
        }

        assertEquals( "E807F1FCF82D132F9BB018CA6738A19F", str );
    }
}
