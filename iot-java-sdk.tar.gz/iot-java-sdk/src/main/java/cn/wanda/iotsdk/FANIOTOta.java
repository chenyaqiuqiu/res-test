package cn.wanda.iotsdk;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.log4j.Logger;
import java.io.FileInputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;

public class FANIOTOta {
	private static final Logger LOGGER = Logger.getLogger(FANDidRegister.class.getName());
	private static final String REQUEST_PATH = "/dev/ota/v4.1/update_and_check/%s";

	private String pk;
	private String did;
	private String host;

	private String downloadUrl;
	private String updateVersion;

	public FANIOTOta (String pk, String did, String host)
	{	
		this.pk = pk;
		this.did = did;
		this.host = host;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public String getUpdateVersion() {
     	LOGGER.debug("software version :" + updateVersion); 
		return updateVersion;
	}

	public boolean requestOtaUrl(String hardwareVersion, String softwareVersion)
	{
		boolean parseOtaSuccess = false;

		try
		{
			String url_request=String.format(REQUEST_PATH,  did);
			URL url = new URL("http",host, url_request);
			LOGGER.debug("url:"+ url.toString());
			
			System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
			
			String content = String.format("passcode=%s&type=1&hard_version=%s&soft_version=%s", 
				pk.substring(0, 10), hardwareVersion, softwareVersion);

			LOGGER.debug("content:"+content);       

	        byte[] post_buf=content.getBytes();

			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setAllowUserInteraction(true);
	        httpConn.setConnectTimeout(3000); // 设置发起连接的等待时间，3s
	        httpConn.setReadTimeout(10000); // 设置数据读取超时的时间，10s
	        httpConn.setUseCaches(false); // 设置不使用缓存
	        httpConn.setDoOutput(true);
	        httpConn.setRequestMethod("POST");
	        httpConn.setDoInput(true);
	        httpConn.setRequestProperty("Host", host);
	        httpConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        httpConn.setRequestProperty("Content-Length", Integer.toString(post_buf.length));
	        
	        //System.out.println("content_send:" + httpConn.content_send);
	        OutputStream os = httpConn.getOutputStream();
	        BufferedOutputStream bos = new BufferedOutputStream(os);
	        	         
	        bos.write(post_buf);
	        bos.flush();
	        
	        System.out.println("httpConn.getResponseCode():"+httpConn.getResponseCode());
	
	        StringBuffer strBuf = new StringBuffer();

			BufferedReader reader;
			if (200 <= httpConn.getResponseCode() && httpConn.getResponseCode() <= 299) {
    			reader = new BufferedReader(new InputStreamReader((httpConn.getInputStream())));
			} else {
    			reader = new BufferedReader(new InputStreamReader((httpConn.getErrorStream())));
			}

	        String line = null;
	        while ((line = reader.readLine()) != null) {
	            strBuf.append(line);
	        }
	        String res = strBuf.toString();
	       	// soft_ver=04020009&download_url=http://iotopenapi.ffan.com/dev/ota/v4.1/download/115
	        System.out.println("OTA request receive: " + res);

	        String[] recvResult = res.split("&");
	        String[] softVersion = recvResult[0].split("=");
	        String[] imageUrl = recvResult[1].split("=");

	        // TODO: check software version
	        if (softVersion[0].equals("soft_ver") && imageUrl[0].equals("download_url")) {
				downloadUrl = imageUrl[1];
				updateVersion = softVersion[1];

				parseOtaSuccess = true;
	        }

	        bos.close();
	        os.close();
	        reader.close();
		}
		catch(Exception ex)
		{
			LOGGER.error(ex.getMessage());
		}

		return parseOtaSuccess;
	}


}
