package cn.wanda.iotsdk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.json.JSONObject;

//public class FANIoTSDK implements FANDidHandler{
public class FANIoTSDK{
	private static final Logger LOGGER = Logger.getLogger(FANIoTSDK.class.getName());

    private String pk;
    private String pkSecret;

    private Map<String,FANIoTSession> sessionMap;
    
    public FANIoTClient mIoTClient; //iot类

    public FANIoTSDK(String mac)
    {

        if (mac == null || mac.length() <= 0)
        {
            LOGGER.fatal("fatal error: missing mac");
            System.exit(-1);
        }

        String hwVersion = ConfigUtil.getProperty("hw_version");
        String swVersion = ConfigUtil.getProperty("sw_version");

        if (hwVersion == null || hwVersion.isEmpty() || 
                swVersion == null || swVersion.isEmpty()) {
            LOGGER.fatal("fatal error: missing version infomation");
            System.exit(-1);
        }

    	LOGGER.debug("init ffan IoT SDK hwVersion: " + hwVersion + " swVersion: " + swVersion);
    	sessionMap = new HashMap<String,FANIoTSession>();
    	
    	pk = ConfigUtil.getProperty("pk");
        pkSecret = ConfigUtil.getProperty("pk_secret");
        if( (pk == null) ||  pk.isEmpty() || (pkSecret == null) || pkSecret.isEmpty())
        {
        	LOGGER.fatal("fatal error: missing pk and pk_secret");
        	System.exit(-1);
        }

        mIoTClient = new FANIoTClient(pk, pkSecret, mac);

        mIoTClient.start();
    }

    public void addDevice(FANIoTDevice d, FANUserMsgHandler h, int heartBeatInterval)
    {
        FANIoTSession session = new FANIoTSession(d, h, mIoTClient, heartBeatInterval);
        sessionMap.put(d.getMac(), session);
        session.start();
    }

    public FANIoTSession getDeviceSession(FANIoTDevice d)
    {
    	return sessionMap.get(d.getMac());
    }

    public FANIoTClient getIoTClient()
    {
        return mIoTClient;
    }

    @Override
    public void finalize()
    {
    	LOGGER.debug("FANIoTSDK finalize");
    	Iterator<Entry<String, FANIoTSession>> iter = sessionMap.entrySet().iterator();
    	while (iter.hasNext()) {
    		Map.Entry<String, FANIoTSession> entry = (Map.Entry<String, FANIoTSession>) iter.next();
    		FANIoTSession session = entry.getValue();
    		if (session != null)
    		{
    			session.finalize();
    		}
    	}
    	
	    if(mIoTClient!=null)
	    {
	        mIoTClient.finalize();
	        mIoTClient = null;
	    }
    }
}
