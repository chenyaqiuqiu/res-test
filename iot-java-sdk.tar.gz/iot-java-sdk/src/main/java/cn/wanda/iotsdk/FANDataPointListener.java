package cn.wanda.iotsdk;

/**
 * Created by Samuel on 2016/12/27.
 */

public interface FANDataPointListener {
    boolean onRevDataPoint(String key, byte[] value);
}

