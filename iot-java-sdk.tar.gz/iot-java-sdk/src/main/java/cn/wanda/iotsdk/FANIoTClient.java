package cn.wanda.iotsdk;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONObject;
import cn.wanda.iotsdk.FANIOTDataPoints;

public class FANIoTClient implements  MqttCallback{
	private static final Logger LOGGER = Logger.getLogger(FANIoTClient.class.getName());

	private static final int MQTT_PAYLOAD_MAX_LENGTH = 15 * 1024;

	private static final int DATAPOINTS_WRITE = 0x01;
	private static final int DATAPOINTS_READ  = 0x02;
	private static final int DATAPOINTS_ACTION_SEND = 0x04;
	private static final int TRANS_ACTION_SEND = 0x06;

	private static final String OPENAPI_URL = ConfigUtil.checkExistKey("openapi_url") 
												? ConfigUtil.getProperty("openapi_url") : "iotopenapi.ffan.com";
	private static final String MQTT_DEFAULT_URL = ConfigUtil.checkExistKey("mqtt_default_url")
													? ConfigUtil.getProperty("mqtt_default_url") : "iotsandbox.ffan.com";
	private static final String MQTT_DEFAULT_PORT = ConfigUtil.checkExistKey("mqtt_default_port")
													 ? ConfigUtil.getProperty("mqtt_default_port") : "10003";


	private String mqttUrl;
	private String mqttPort;

	private String pk;
	private String pk_secret;
	private String mac;
	private String did;

	private boolean connecttedToIoT;
	private  List<FANMsgEventPair> mMsgEventPairList;
	private int clientMsgId = 0;

	private MqttAsyncClient mqttClient;
	private FANIOTOta otaClient;
	private FANIOTDataPoints dataPointsClient;

	private FANDataPointListener dataPointListener;
	private FANOtaListener otaListener;

	private int failedCounts = 0;

	public FANIoTClient(String pk, String pk_secret, String mac)
	{
		mMsgEventPairList = new ArrayList<FANMsgEventPair>();

		this.pk = pk;
		this.pk_secret = pk_secret;
		this.mac = mac;

		String dataPointsPath = ConfigUtil.getProperty("dataPointsPath");
		dataPointsClient = new FANIOTDataPoints(dataPointsPath);
		dataPointsClient.initDataPoint();
	}

	public String getPK()
	{
		return pk;
	}

	public String getTarget()
	{
		return mqttUrl;
	}

	public void updateDataPoint(String name, String value) {
		dataPointsClient.updateDataPoint(name, value);
	}

	public void syncDataPoint() {
		byte[] dataToSync = dataPointsClient.createUpdateFrame();
		sendDataPointsData(dataToSync);
	}

	public void setDataPointListener(FANDataPointListener listener) {
		dataPointListener = listener;
	}

	private void processWritableDataPoint(JSONObject dataJson) {
		if (dataPointListener != null && dataJson != null) {
			try {
				Iterator iterator = dataJson.keys();
				boolean needSync = false;
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					String value = dataJson.getString(key);
					boolean ret = dataPointListener.onRevDataPoint(key, value.getBytes());
					if(ret) {
						updateDataPoint(key, value);
						needSync |= ret;
					}
				}
				if(needSync) {
					syncDataPoint();
				}
			} catch (Exception e) {
				LOGGER.error("failed to parse data point " + e.toString());
			}
		}
	}

	private void sendDev2appData (byte action, byte[] payload) throws Exception
	{
		
		if (payload.length > MQTT_PAYLOAD_MAX_LENGTH) {
			throw new Exception("mqtt payload overload");
		}

		int actionLength = 1;
		byte[] header = new byte[]{0x00, 0x00, 0x00, 0x03};
		byte[] flag = new byte[]{0x00};
		byte[] cmd = new byte[]{0x00, (byte)0x91};

		byte[] dataLength = FANUtils.length2bytes(payload.length + header.length);		
		int length = header.length + dataLength.length + flag.length
			+ cmd.length + actionLength + payload.length;

		byte[] buffer = new byte[length];
		ByteBuffer byteBuffer = ByteBuffer.wrap(buffer);

		byteBuffer.put(header);
		byteBuffer.put(dataLength);
		byteBuffer.put(flag);
		byteBuffer.put(cmd);
		byteBuffer.put(action);
		byteBuffer.put(payload);

		byte[] sendBuffer= byteBuffer.array();
		try {
			String dev2appTopic =  String.format("dev2app/%s", did);
			// enable this line after iot platform support compress
			IMqttDeliveryToken pubToken = mqttClient.publish(dev2appTopic, sendBuffer, 1, false);
			pubToken.waitForCompletion();
		} catch (MqttPersistenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sendTransparentData(byte[] payload) {
		byte action = TRANS_ACTION_SEND;
		byte[] compressMqttPayload = new byte[MQTT_PAYLOAD_MAX_LENGTH];

        try {
            compressMqttPayload = FANUtils.compressWithOpt(payload);
        } catch(IOException e) {
            LOGGER.error(e.toString());
        }

        String compressVerion = "v1.0";
        byte[] payloadWithVersion = new byte[compressMqttPayload.length + compressVerion.length()];
        	
        System.arraycopy(compressVerion.getBytes(), 0, payloadWithVersion, 0, compressVerion.length());
        System.arraycopy(compressMqttPayload, 0, payloadWithVersion, compressVerion.length(), compressMqttPayload.length);

		try {
			sendDev2appData(action, payloadWithVersion);
		} catch (Exception e) {
			LOGGER.error("mqtt send transParent error:  " + e.toString());
		}
	}

	public void sendDataPointsData(byte[] payload) {
		byte action = DATAPOINTS_ACTION_SEND;
		//LOGGER.debug("send dataPoints: " + FANUtils.bytesToHexString(payload));
		try {
			sendDev2appData(action, payload);
		} catch (Exception e) {
			LOGGER.error("mqtt send dataPoints error:  " + e.toString());
		}
	}

	@Override
	public void  deliveryComplete(IMqttDeliveryToken token)
	{
	}

	public void addEventHandler(FANEventHandler h) { 
		FANMsgEventPair p = new FANMsgEventPair(h, 0);
		mMsgEventPairList.add(p);
	}

	public void setEventHandlerUuid(FANEventHandler h, String uuid) { 
		for (FANMsgEventPair p:mMsgEventPairList) {
			if (p.getEventHandler() == h) {
				p.setUuid(uuid);
				break;
			}
		}
	}

	public void setEventHandlerMessageId(FANEventHandler h, int msgId) { 
		for (FANMsgEventPair p:mMsgEventPairList) {
			if (p.getEventHandler() == h) {
				p.setMsgID(msgId);
				break;
			}
		}
	}

	public int getUniqueMessageId() {            
		synchronized(this)
        {
			clientMsgId++;
		}

		return clientMsgId;
	}

	private void handleIoTFeedbackMessage(JSONObject recvJson) {
		int targetMsgID = recvJson.optInt("MsgID", 0);

		if (mMsgEventPairList != null ) {
			for (FANMsgEventPair p:mMsgEventPairList) {
				if (p.getMsgID() == targetMsgID) {
					if (p.getEventHandler() != null) {
						p.getEventHandler().handleMsg(recvJson);
					}
					break;
				}
			}
		}
	}

	private void handleIoTRequestMessage(JSONObject recvJson) {
		JSONObject request = recvJson.getJSONObject("Request");

		if (request != null && request.has("UUID")) {
			String uuidInJson = request.getString("UUID");
			if (uuidInJson == null)
				return;

			for (FANMsgEventPair p:mMsgEventPairList) {
				if (p.getUuid().equals(uuidInJson)) {
					if (p.getEventHandler() != null)
						p.getEventHandler().handleMsg(recvJson);
				}
			}
		}
	}

	private void handleApp2devMessage(byte[] data) {
		//LOGGER.debug("recv data:" + FANUtils.bytesToHexString(data));
		int startPos = 0;
		for (int i = 5; i < 8; i++)
		{
			if ((data[i] == (byte)0x00) && (data[i + 1] == (byte)0x00) 
				&& (data[i + 2] == (byte)0x90))
			{
				startPos = i + 4;
				break;
			}
		}

		byte[] rawData = new byte[data.length - startPos];
		System.arraycopy(data, startPos, rawData, 0, data.length - startPos);

		int action = data[8];
		if(action == DATAPOINTS_WRITE) {
			JSONObject result = dataPointsClient.decodeWritableFrame(rawData);
			LOGGER.debug("data points write :" + result.toString());
			processWritableDataPoint(result);
			return;
		} else if (action == DATAPOINTS_READ) {
			syncDataPoint();
			return;
		} else {
			// ffan private protocol
			try {
				byte[] jsonRawData;
                if (rawData[0] == 'v' && rawData[1] == '1' && rawData[2] == '.') {
                    byte[] payload = new byte[rawData.length - 4];
                    System.arraycopy(rawData, 4, payload, 0, payload.length);
                    jsonRawData = FANUtils.uncompressWithOpt(payload);
                } else {
                    jsonRawData = rawData;
                }

				String jsonStr = new String((byte[])jsonRawData, "utf-8");
				JSONObject recvJson = new JSONObject(jsonStr);
				if (recvJson != null) {
					LOGGER.debug("Get ffan message:" + recvJson.toString());

					if (recvJson.has("Result")) {
						handleIoTFeedbackMessage(recvJson);
					}

					if (recvJson.has("Request") && recvJson.has("Method")) {
						handleIoTRequestMessage(recvJson);
					}
				}
			} catch (Exception ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
	}

	private void handleSer2cliMessage(byte[] data) {
		byte[] compressMqttPayload = new byte[1024];
		
		try{
			compressMqttPayload = FANUtils.uncompressWithOpt(data);
		} catch(IOException ex) {
			ex.printStackTrace();
		}
		if (compressMqttPayload[4] == 0x02 && compressMqttPayload[5] == 0x11) {
			requestOtaUrl();
		}
	}

	@Override
		public void messageArrived(String topic, MqttMessage message) throws MqttException {

			byte[] data = message.getPayload();
			if (topic.startsWith("app2dev")) {
				handleApp2devMessage(data);
			} else if(topic.startsWith("ser2cli_res")) {
				handleSer2cliMessage(data);
			}
		}


	@Override
	public void connectionLost(Throwable cause) {
			// Called when the connection to the server has been lost.
			// An application may choose to implement reconnection
			// logic at this point. This sample simply exits.
			LOGGER.error("Connection to " + mqttUrl + " lost!" + cause);
			for (FANMsgEventPair p:mMsgEventPairList)
			{
				if (p.getEventHandler() != null)
				{
					p.getEventHandler().disconnected();
				}
			}
			if (connecttedToIoT)
			{
				try {
					Thread.sleep(5000);
					LOGGER.debug("reconnect");
					mqttClient.reconnect();
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
			}
	}
	
	public boolean getConnected() {
		if(mqttClient == null)
			return false;
		else
			return mqttClient.isConnected();
	}
	
	private boolean connectToMqttServer(String url, String port) {
		String protocol = "";
		String sslSet = ConfigUtil.getProperty("use_ssl");
		if (sslSet != null && sslSet.equals("true")) {
			protocol = "ssl://";
		} else {
			protocol = "tcp://";
		}

		String brokerUrl= protocol + url + ":" + port;
		String clientId = did;

		MemoryPersistence dataStore = new MemoryPersistence();
		LOGGER.debug("brokerUrl: "+ brokerUrl + " clientId: " + clientId);
		try {
			mqttClient = new MqttAsyncClient(brokerUrl, clientId, dataStore);
			// Set this wrapper as the callback handler
			mqttClient.setCallback(this);
		} catch (Exception e) {
			LOGGER.error(e.toString());
			return false;
		}

		try{
			MqttConnectOptions conOpt = new MqttConnectOptions();
			conOpt.setCleanSession(true);

			String password = pk.substring(0, 10);
			if(password != null ) {
				conOpt.setPassword(password.toCharArray());
			}

			String userName = did;
			if(userName != null) {
				conOpt.setUserName(userName);
			}
			LOGGER.debug("userName: " + userName + " password: "+ password);

			conOpt.setConnectionTimeout(10); 
			conOpt.setKeepAliveInterval(30); 
			IMqttToken conToken = mqttClient.connect(conOpt);
			conToken.waitForCompletion();
			LOGGER.debug("Mqtt client Connected");
		} catch (Exception e) {
			failedCounts++;
			ConfigUtilTest.setProperty(mac + "_mqttFailed", String.valueOf(failedCounts));
			LOGGER.error( "mqtt connect failed: " + e.toString());
			return false;
		}

		for (FANMsgEventPair p:mMsgEventPairList) {
			if (p.getEventHandler() != null) {
				p.getEventHandler().connected();
			}
		}

		return true;
	}

	private void subscribeMqttTopic() {
		//订阅主题
		try {
			String subSer2cliTopic = String.format("ser2cli_res/%s",did);
			IMqttToken subToken0 = mqttClient.subscribe(subSer2cliTopic, 1);
			subToken0.waitForCompletion();
			LOGGER.debug("Subscribed to topic:" + subSer2cliTopic);

			String subApp2devTopic = String.format("app2dev/%s/#", did);
			IMqttToken subToken1 = mqttClient.subscribe(subApp2devTopic, 1);
			subToken1.waitForCompletion();
			LOGGER.debug("Subscribed to topic:" + subApp2devTopic);
		} catch (Exception e) {
			LOGGER.error(e.toString());
		}
	}

	private void createOtaClient() {
		otaClient = new FANIOTOta(pk, did, OPENAPI_URL);
	}

	private void requestOtaUrl() {
		boolean ret = otaClient.requestOtaUrl(ConfigUtil.getProperty("hw_version"), 
				ConfigUtil.getProperty("sw_version"));

		if (ret) {
			String downloadUrl = otaClient.getDownloadUrl();
			String swVersion = otaClient.getUpdateVersion();

			LOGGER.debug("recv downloadUrl: " + downloadUrl + " swVersion: " + swVersion);
			if (otaListener != null) {
				otaListener.onOtaMessage(swVersion, downloadUrl);
			}
		}
	}

	public void updateSwVersion(String swVersion) {
		ConfigUtil.setProperty("sw_version", swVersion);
	}

	public void setOtaListener(FANOtaListener listener) {
		otaListener = listener;
	}

	public void start()
	{
		connecttedToIoT = false;

		while(!connecttedToIoT) {
			FANDidRegister didRegister = new FANDidRegister(pk, pk_secret, mac, OPENAPI_URL);
			int ret = didRegister.register();
			if (ret == 0) {
				did = didRegister.getDid();
				//ConfigUtil.setProperty("did", did_reg.getDid());
				LOGGER.debug("IOT allocate did: " + did);

				didRegister.provision();
				mqttUrl = didRegister.getMqttUrl();
				mqttPort = didRegister.getMqttPort();
				if (mqttUrl == null || mqttUrl.isEmpty() || mqttPort == null || mqttPort.isEmpty()) {
					mqttUrl = MQTT_DEFAULT_URL;
					mqttPort = MQTT_DEFAULT_PORT;
				}

				if (connectToMqttServer(mqttUrl, mqttPort)) {
					subscribeMqttTopic();
					
					createOtaClient();
					requestOtaUrl();

					connecttedToIoT = true;	
				}
			} else {
				try {
					// register did and reconnect mqtt server after 10s
					Thread.sleep(10 * 1000);
				} catch(Exception ex) {       		
				}

				continue;
			}
		}	
	}

	@Override
		protected void finalize()
		{
			LOGGER.debug("FANIoTClient finalize");

			connecttedToIoT = false;
			try {
				if (mqttClient.isConnected())
				{
					IMqttToken discToken = mqttClient.disconnect();
					discToken.waitForCompletion();
				}
				mqttClient.close();
			} catch (MqttException e) {
				LOGGER.error(e.getMessage());
			}
		}
}
