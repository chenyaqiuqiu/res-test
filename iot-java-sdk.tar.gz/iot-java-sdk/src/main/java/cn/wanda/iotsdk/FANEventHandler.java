package cn.wanda.iotsdk;

import org.json.JSONObject;

/**
 * Created by Samuel on 2017/1/3.
 */

public interface FANEventHandler {
    void handleMsg(JSONObject msg);
    void connected();
    void disconnected();
}
