package cn.wanda.iotsdk;

import java.util.concurrent.TimeUnit;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import org.json.JSONObject;

import java.io.File;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.RequestBody;

import org.apache.log4j.Logger;

public class FANIoTHttpChannel {
	private static final Logger LOGGER = Logger.getLogger(FANIoTHttpChannel.class.getName());
    protected static FANIoTHttpChannel instance;
	private OkHttpClient mClient;

    private static int connectTimeout = 10;
    private static int writeTimeout = 30;
    private static int readTimeout = 30;
	private FANIoTHttpChannel()
	{
		mClient = new OkHttpClient.Builder()
                    .connectTimeout(connectTimeout, TimeUnit.SECONDS)
                    .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                    .readTimeout(readTimeout, TimeUnit.SECONDS)
        			.build(); 
	}

    public static void setChannelTimeout(int c, int w, int r) {
        connectTimeout = c;
        writeTimeout = w;
        readTimeout = r;
    }

    public static FANIoTHttpChannel getInstance() {
        if (instance == null) {
            synchronized (FANIoTHttpChannel.class) {
                if (instance == null) {
                    instance = new FANIoTHttpChannel();
                }
            }
        }
        return instance;
    }

    public void reportUserFile(String url, String msg, File file, Callback callback) {
        LOGGER.debug("postFile begin " + Thread.currentThread().toString());
        LOGGER.debug("msg: " + msg);

        RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), file);
        RequestBody requestbody = new MultipartBody.Builder()
                .setType(MultipartBody.MIXED)
                .addPart(Headers.of(
                        "Content-Disposition",
                        "form-data; name=devInfo"),
                        RequestBody.create(null, msg))
                .addPart(Headers.of(
                        "Content-Disposition",
                        "form-data; name=devData"), fileBody)
                .build();

        final Request request = new Request.Builder()
                .post(requestbody)
                .tag(this)
                .url(url)
                .build();
        //LOGGER.debug("request body " + request.body().toString());
        try {
            Call call = mClient.newCall(request);
            if (callback != null) {
                call.enqueue(callback);
            } else {
                Response response = call.execute();
                System.out.println(response.body().string());
            }
        } catch (Exception e) {
            LOGGER.error("postFile " + e.toString());
        }
    }

    public void reportUserFile(String url, String msg, byte[] content, Callback callback) {
        RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), content);
        RequestBody requestbody = new MultipartBody.Builder()
                .setType(MultipartBody.MIXED)
                .addPart(Headers.of(
                        "Content-Disposition",
                        "form-data; name=devInfo"),
                        RequestBody.create(null, msg))
                .addPart(Headers.of(
                        "Content-Disposition",
                        "form-data; name=devData"), fileBody)
                .build();

        final Request request = new Request.Builder()
                .post(requestbody)
                .tag(this)
                .url(url)
                .build();
        //LOGGER.debug("request body " + request.body().toString());
        try {
            Call call = mClient.newCall(request);
            if (callback != null) {
                call.enqueue(callback);
            } else {
            	Response response = call.execute();
    			System.out.println(response.body().string());
            }
        } catch (Exception e) {
            LOGGER.error("postBytes " + e.toString());
        }
    }

    public void reportUserFile(String url, String msg, List<String> fileNames ,List<byte[]> contents, Callback callback) {
        LOGGER.debug("postFile begin " + Thread.currentThread().toString());
        LOGGER.debug("msg " + msg);
        RequestBody requestbody;

        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.MIXED)
                .addPart(Headers.of(
                        "Content-Disposition",
                        "form-data; name=devInfo"),
                        RequestBody.create(null, msg));
        for (int i = 0; i < contents.size(); i++) {
            RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), contents.get(i));
            String fileName = fileNames.get(i);
            builder.addPart(Headers.of(
                    "Content-Disposition",
                    "form-data; name=" + fileName), fileBody);
        }
        requestbody = builder.build();

        final Request request = new Request.Builder()
                .post(requestbody)
                .tag(this)
                .url(url)
                .build();
        LOGGER.debug("request body " + request.body().toString());
        try {
            Call call = mClient.newCall(request);
            if (callback != null) {
                call.enqueue(callback);
            }else {
                Response response = call.execute();
                System.out.println(response.body().string());
            }
        } catch (Exception e) {
            LOGGER.debug("postFile " + e.toString());
        }
    }
}
