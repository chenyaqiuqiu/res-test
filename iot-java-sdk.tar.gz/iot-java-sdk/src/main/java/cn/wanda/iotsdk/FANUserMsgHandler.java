package cn.wanda.iotsdk;

import org.json.JSONObject;

public interface FANUserMsgHandler {
	void handleMsg(JSONObject msg);
	void logined();
}
