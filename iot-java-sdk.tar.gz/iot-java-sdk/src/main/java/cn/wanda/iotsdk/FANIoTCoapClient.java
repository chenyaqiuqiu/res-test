package cn.wanda.iotsdk;

import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import java.io.File;
import java.net.URI;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.network.Endpoint;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.Utils;
import org.eclipse.californium.core.coap.MediaTypeRegistry;

import org.apache.log4j.Logger;

public class FANIoTCoapClient extends CoapClient{
	private static final Logger LOGGER = Logger.getLogger(FANIoTCoapClient.class.getName());
	private CoapClient coapClient;

	private FANIoTCoapClient(URI uri)
	{
        coapClient = new CoapClient(uri);
	}

    /*
        handler:
        @Override public void onLoad(CoapResponse response) {}
        @Override public void onError() {}
    */
    public void post(CoapHandler handler, String payload) {
        coapClient.post(handler, payload, MediaTypeRegistry.TEXT_PLAIN);
    }

    public void post(CoapHandler handler, byte[] payload) {
        coapClient.post(handler, payload, MediaTypeRegistry.TEXT_PLAIN);
    }

    public void put(CoapHandler handler, String payload) {
        coapClient.put(handler, payload, MediaTypeRegistry.TEXT_PLAIN);
    }

    public void put(CoapHandler handler, byte[] payload) {
        coapClient.put(handler, payload, MediaTypeRegistry.TEXT_PLAIN);
    }

    public CoapClient setEndpoint(Endpoint endpoint) {
        return coapClient.setEndpoint(endpoint);
    }

    public Endpoint getEndpoint() {
        return coapClient.getEndpoint();
    }

    public void get(CoapHandler handler) {
        coapClient.get(handler);
    }
}
