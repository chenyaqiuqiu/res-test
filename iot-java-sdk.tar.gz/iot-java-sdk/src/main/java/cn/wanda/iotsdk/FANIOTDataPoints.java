package cn.wanda.iotsdk;

import java.io.*;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
import java.util.ArrayList;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.FileOutputStream;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import org.apache.log4j.Logger;
import cn.wanda.iotsdk.FANUtils;

class DataPointsItems {
    public String DataPointName;
    public String RWType;
    public String DataType;
    public String DataCurVal;
    public String DataMinVal;
    public String DataMaxVal;
    public String DataResolution;
    public String DataIncrement;
    public String DataLen;
    //public String DataValid;
}

class DataPointsStruct {
    public int paramsCount;
    public ArrayList paramsList;

    public DataPointsStruct() {
       paramsList = new ArrayList();
   }
}

public class FANIOTDataPoints {

	private static final Logger LOGGER = Logger.getLogger(FANUtils.class.getName());
	private DataPointsStruct dataPointsStruct;
    private static String dataPointsJsonFile;
    private JSONObject dataPointsJson;

    public FANIOTDataPoints(String configFile)
    {
        dataPointsJsonFile = configFile;
        dataPointsStruct = new DataPointsStruct();
        dataPointsJson = new JSONObject();
    }

    private void verifyDataPointsJsonFile()
    {

    }

    public void initDataPoint() {
        String jsonStr = "";

        try {
            jsonStr = new String(Files.readAllBytes(Paths.get(dataPointsJsonFile)));
        }   catch(Exception ex) {
            LOGGER.error(ex.toString());
        }

        //JSONObject json = new JSONObject(jsonStr);
        dataPointsJson = new JSONObject(jsonStr);

        if (dataPointsJson.has("Params")) {
            JSONArray params = dataPointsJson.getJSONArray("Params");
            dataPointsStruct.paramsCount = params.length();

            for (int i = 0; i < dataPointsStruct.paramsCount; i++) {     
                JSONObject paramsItem = params.getJSONObject(i);
                if (paramsItem != null) {
                    DataPointsItems dataPointsItem = new DataPointsItems();

                    dataPointsItem.DataPointName = paramsItem.getString("DataPointName");
                    dataPointsItem.RWType = paramsItem.getString("RWType");
                    dataPointsItem.DataType = paramsItem.getString("DataType");
                    dataPointsItem.DataCurVal = paramsItem.getString("DataCurVal");
                    dataPointsItem.DataMinVal = paramsItem.getString("DataMinVal");
                    dataPointsItem.DataMaxVal = paramsItem.getString("DataMaxVal");
                    dataPointsItem.DataResolution = paramsItem.getString("DataResolution");
                    dataPointsItem.DataIncrement = paramsItem.getString("DataIncrement");
                    dataPointsItem.DataLen = paramsItem.getString("DataLen");
                    //dataPointsItem.DataValid = paramsItem.getString("DataValid");

                    dataPointsStruct.paramsList.add(dataPointsItem);
                }
            }
        }
    }

    public void updateDataPoint(String name, String value) {
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) { 
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem == null)
                return;

            if (dataPointsItem.DataPointName.equals(name)) {
                dataPointsItem.DataCurVal = value;
            }
        }

        updateDataPointInDisk(name, value);
    }

    private void updateDataPointInDisk(String key, String value) {
        if (dataPointsJson == null)
            return;

        try {
            if (dataPointsJson.has("Params")) {
                JSONArray params = dataPointsJson.getJSONArray("Params");

                for (int i = 0; i < params.length(); i++) {
                    JSONObject paramsItem = params.getJSONObject(i);
                    if (paramsItem != null && paramsItem.getString("DataPointName").equals(key)) {
                        LOGGER.debug("update dataPoints in disk: key:" + key + " value: " + value);
                        paramsItem.put("DataCurVal", value);
                    }
                }
            }
        }catch (JSONException e) {
            LOGGER.error(e.toString());
        }

        String dataPointsJsonString = dataPointsJson.toString();
        try {
            FileOutputStream outStream = new FileOutputStream(new File(dataPointsJsonFile));
            outStream.write(dataPointsJsonString.getBytes());
            outStream.close();
        }catch(IOException e) {
            LOGGER.error(e.getMessage());
        }
    }

    public byte[] createUpdateFrame() {
        byte[] writable = encodeFrameByType("WRITABLE");
        byte[] readonly = encodeFrameByType("READONLY");
        byte[] alarm = encodeFrameByType("ALARM");
        byte[] fault = encodeFrameByType("FAULT");

        int resLength = writable.length + readonly.length + alarm.length + fault.length;
        byte[] result = new byte[resLength];
        // System.arraycopy(src, srcPos, dest, destPos, length)
        System.arraycopy(writable, 0, result, 0, writable.length);
        System.arraycopy(readonly, 0, result, writable.length, readonly.length);
        System.arraycopy(alarm, 0, result, writable.length + readonly.length, alarm.length);
        System.arraycopy(fault, 0, result, writable.length + readonly.length + alarm.length, fault.length);

        return result;
    }

    private byte[] encodeFrameByType(String type) {
        byte[] boolsAndEnum = encodeBoolsAndEnum(type);
        byte[] numbers =  encodeNumber(type);
        byte[] binarys = encodeBinBuffer(type);

        int resLength = boolsAndEnum.length + numbers.length + binarys.length;
        byte[] result = new byte[resLength];

        System.arraycopy(boolsAndEnum, 0, result, 0, boolsAndEnum.length);
        System.arraycopy(numbers, 0, result, boolsAndEnum.length, numbers.length);
        System.arraycopy(binarys, 0, result, boolsAndEnum.length + numbers.length, binarys.length);

        return result;
    }

    // calculate bit width for one value
    private int calcValueBitWidth(int n) {
        int i = 0;
        do {
            i++;
        }while((n >> i) > 0);

        return i;
    }

    private byte[] encodeBoolsAndEnum(String type) {
        byte[] resBuffer = new byte[1024];
        int hasValue = 0;
        int offset = 0;
        int byteOffset = 0;
        int lastBitIndex = 0;
        int byteLength = 0;

        for (int i = 0; i < dataPointsStruct.paramsCount; i++) { 
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals(type)) {
                    if (dataPointsItem.DataType.equals("BOOL")) {
                        hasValue = 1;
                        int curval = Integer.parseInt(dataPointsItem.DataCurVal);
                        resBuffer[byteOffset] |= (curval << offset);
                        offset++;
            
                        if(offset >= 8) {
                            byteOffset++;
                            offset -= 8;
                        }
                    }
                }
            }
        }

        lastBitIndex = offset;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals(type)) {
                    if (dataPointsItem.DataType.equals("ENUM")) {
                        hasValue = 1;
                        int enumMaxValue = Integer.parseInt(dataPointsItem.DataMaxVal);
                        int curval = Integer.parseInt(dataPointsItem.DataCurVal);
                        int bitNumber = calcValueBitWidth(enumMaxValue);
                        //LOGGER.debug("bit NUmber %d lastBit %d curval %x\n" + bitNumber + lastBitIndex + curval);
                        if ((bitNumber + lastBitIndex) < 8) {
                            resBuffer[byteOffset] |= (curval << lastBitIndex);
                            lastBitIndex += bitNumber;
                            //printf("data %x offset %d lastBitIndex %d\n", resBuffer[byteOffset], byteOffset, lastBitIndex);
                        } else {
                            resBuffer[byteOffset] |= (curval << lastBitIndex);
                            //printf("data0 %x offset %d lastbit %d\n", resBuffer[byteOffset], byteOffset, lastBitIndex);
                            if ((bitNumber + lastBitIndex) > 8) {
                                byteOffset++;
                                resBuffer[byteOffset] |= (curval >> (8 - lastBitIndex));
                            }
    
                            lastBitIndex = bitNumber + lastBitIndex - 8;
                            //printf("data1 %x offset %d lastbit %d\n", resBuffer[byteOffset], byteOffset, lastBitIndex);
                        }

                    }
                }
            }
        }

        if(hasValue > 0) {
            byteLength = byteOffset + 1;
        }
        
        return reverseBytesOrder(resBuffer, byteLength);
    }

    private int calNumberPayloadLength(String pCurNum, String pNumRes, String pNumIncr, String pNumMax) {
        int EncLen;
        float CurNum = Float.parseFloat(pCurNum);
        float NumMax = Float.parseFloat(pNumMax);
        float NumRes = Float.parseFloat(pNumRes);
        
        if(NumRes == 0)
            NumRes = 1;
    
        float NumIncr = Float.parseFloat(pNumIncr);
        int EncNum = (int)((CurNum - NumIncr)/NumRes);
        int EncNumMax = (int)((NumMax - NumIncr)/NumRes);

        EncNumMax = Math.max(EncNum, EncNumMax);
        
        // LOGGER.debug("EncNumMax: " + EncNumMax);
        if(EncNumMax <= 0x0FF)
            EncLen = 1;
        else if(EncNumMax > 0x0FF && EncNumMax <= 0x0FFFF)
            EncLen = 2;
        else
            EncLen = 4;

        return EncLen;
    }
    
    private int calNumberRefenceValue(String pCurNum, String pNumRes, String pNumIncr) {
        float CurNum = Float.parseFloat(pCurNum);
        float NumRes = Float.parseFloat(pNumRes);
        float NumIncr = Float.parseFloat(pNumIncr);
        
        if(NumRes == 0)
            NumRes = 1;
    
        return (int)((CurNum - NumIncr)/NumRes);
    }

    private int calNumberRealValue(String pCurNum, String pNumRes, String pNumIncr) {
        float CurNum = Float.parseFloat(pCurNum);
        float NumRes = Float.parseFloat(pNumRes);
        float NumIncr = Float.parseFloat(pNumIncr);
        
        if(NumRes == 0)
            NumRes = 1;
        
        return (int)((NumRes * CurNum) + NumIncr);
    }

    private byte[] reverseBytesOrder(byte[] number, int numberLen) {
        byte[] result = new byte[numberLen];

        for(int i = 0; i < numberLen; i++) {
            result[numberLen - i - 1] = number[i];
        }

        return result;
    }

    private byte[] encodeNumber(String type) {
        byte[] result = new byte[0];

        for (int i = 0; i < dataPointsStruct.paramsCount; i++) { 
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {

            if (dataPointsItem.RWType.equals(type)) {
                if (dataPointsItem.DataType.equals("NUMBER")) {

                    int numberLen = calNumberPayloadLength(dataPointsItem.DataCurVal, dataPointsItem.DataResolution, 
                                                    dataPointsItem.DataIncrement, dataPointsItem.DataMaxVal);

                    int number = calNumberRefenceValue(dataPointsItem.DataCurVal, dataPointsItem.DataResolution,
                                                dataPointsItem.DataIncrement);                   

                    // LOGGER.debug("DataPointName: " + dataPointsItem.DataPointName + " number: " + number + " numberLen: " + numberLen);
                    //byte[] str = reverseBytesOrder(FANUtils.intToBytes(number), numberLen);
                    byte[] str = FANUtils.intToBytes(number, numberLen);
                    byte[] temp = new byte[result.length];
                    System.arraycopy(result, 0, temp, 0, result.length);
                    result = new byte[temp.length + str.length];
                    System.arraycopy(temp, 0, result, 0, temp.length);
                    System.arraycopy(str, 0, result, temp.length, str.length);
                }
            }
            }
        }

        return result;    
    }

    private byte[] encodeBinBuffer(String type) {
        byte[] result = new byte[0];

        for (int i = 0; i < dataPointsStruct.paramsCount; i++) { 
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
            if (dataPointsItem.RWType.equals(type)) {
                if (dataPointsItem.DataType.equals("BINARY")) {
                    int binLength = Integer.parseInt(dataPointsItem.DataLen);
                    byte[] str = new byte[binLength];
                    byte[] hexBytes = FANUtils.hexStringToBytes(dataPointsItem.DataCurVal);
                    System.arraycopy(hexBytes, 0, str, 0, hexBytes.length);
                    
                    byte[] temp = new byte[result.length];
                    System.arraycopy(result, 0, temp, 0, result.length);
                    result = new byte[temp.length + str.length];
                    System.arraycopy(temp, 0, result, 0, temp.length);
                    System.arraycopy(str, 0, result, temp.length, str.length);
                }
            }
            }
        }

        return result;
    }

    private int getWritableItemsNumbers() {
        int writableItemsNumber = 0;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    writableItemsNumber++;
                }
            }
        }

        return  writableItemsNumber;
    }

    private int getWriteableBooleanBitsNumbers() {
        int numbers = 0;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("BOOL")) {
                        numbers++;
                    }
                }
            }
        }

        return  numbers;
    }

    private int getWriteableEnumBitsNumbers() {
        int numbers = 0;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("ENUM")) {
                        int enumMaxValue =  Integer.parseInt(dataPointsItem.DataMaxVal);
                        int bitNumber = calcValueBitWidth(enumMaxValue);
                        numbers += bitNumber;
                    }
                }
            }
        }

        return  numbers;
    }

    // calculate bytes width for one value
    private int calcValueBytesWidth(int n) {
        int result = 0;
        int left;

        result = n / 8;
        left = n % 8;
        if (left > 0)
            result++;
    
        return result;
    }

    private int bytesToIntValue(byte[] buffer, int len) {
        int ret = 0;
        for (int i = 0; i < len; i++) {
            ret |= (buffer[i] & 0x0FF) << (8 * (len - i - 1));
        }

        return ret;
    }

    public JSONObject decodeWritableFrame(byte[] input) {
        JSONObject root = new JSONObject();
        
        int writableItemsNumbers = getWritableItemsNumbers();
        int flagLength = calcValueBytesWidth(writableItemsNumbers);
        
        LOGGER.debug("flag length: " + flagLength);
        byte[] flag = new byte[flagLength];
        System.arraycopy(input, 0, flag, 0, flagLength);

        int booleanBitsNumbers = getWriteableBooleanBitsNumbers();
        int enumBitsNumbers = getWriteableEnumBitsNumbers();
        int booleanAndEnumLength = calcValueBytesWidth(booleanBitsNumbers + enumBitsNumbers);
        LOGGER.debug("boolean enum take: " + booleanAndEnumLength);
        
        byte[] booleanAndEnumPayload = new byte[booleanAndEnumLength];
        System.arraycopy(input, flagLength, booleanAndEnumPayload, 0, booleanAndEnumLength);
        byte[] numbersAndBinPayload = new byte[input.length - flagLength - booleanAndEnumLength];
        System.arraycopy(input, flagLength  + booleanAndEnumLength, numbersAndBinPayload, 0, numbersAndBinPayload.length);

        int flagIndex = 0;
        int index = 0;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("BOOL")) {
                        int writeControlByte = flag[flagLength - 1 - flagIndex] & 0x0FF;
                        int writeValueByte = booleanAndEnumPayload[booleanAndEnumLength - 1 - flagIndex] & 0x0FF;
                        LOGGER.debug("writeControlByte: " +  writeControlByte + " writeValueByte: " + writeValueByte + " index: " + index);
                        if (((writeControlByte >> index) & 0x01) > 0) {
                            int booleanValue = (writeValueByte >> index) & 0x01;
                            root.put(dataPointsItem.DataPointName, Integer.toString(booleanValue));
                        }
                        
                        index += 1;
                        if (index % 8 == 0 && index != 0) {
                            index = 0;
                            flagIndex++;
                        }
                    }
                }
            }
        }

        int enumIndex = flagIndex;
        int enumValueIndex = index;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("ENUM")) {
                        int enumMaxValue = Integer.parseInt(dataPointsItem.DataMaxVal);
                        int bitNumber = calcValueBitWidth(enumMaxValue);
                        int writeBitValue = 0;
                        if (enumValueIndex + bitNumber <= 8) {
                            writeBitValue = booleanAndEnumPayload[booleanAndEnumLength - 1 - enumIndex] & 0x0FF;
                            writeBitValue = (writeBitValue >> enumValueIndex) & (0xFF >> (8 - bitNumber));
                    
                            enumValueIndex += bitNumber;
                            if (enumValueIndex == 8) {
                                enumIndex += 1;
                                enumValueIndex = 0;
                            }
                        } else {
                            int enumTempValue = booleanAndEnumPayload[booleanAndEnumLength - 1 - enumIndex] & 0x0FF;
                            int firstBitValue = enumTempValue >> enumValueIndex;
                            LOGGER.debug("valueIndex: " + enumValueIndex + " firstBit: " + firstBitValue);
                            enumIndex += 1;
                            enumTempValue = booleanAndEnumPayload[booleanAndEnumLength - 1 - enumIndex] & 0x0FF;
                            int enumTempIndex = enumValueIndex + bitNumber - 8;
                            int secondBitValue = enumTempValue & (0xFF >> (8 - enumTempIndex));
                    
                            LOGGER.debug("valueIndex: " + enumTempIndex + " secondBit: " + secondBitValue);
                            writeBitValue = (secondBitValue << (8 - enumValueIndex)) | firstBitValue;
                            enumValueIndex =  enumTempIndex;
                        }
    
                        int writeBitControl = flag[flagLength - 1 - flagIndex] & 0x0FF;
                        if ((writeBitControl >> index & 0x01) > 0) {
                            root.put(dataPointsItem.DataPointName, Integer.toString(writeBitValue));
                        }
                        
                        index += 1;
                        if (index % 8 == 0 && index != 0) {
                            index = 0;
                            flagIndex++;
                        }
                    }
                }
            }
        }

        int numbersAndBinPayloadOffset = 0;
        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("NUMBER")) {
                        int writeBitControl = flag[flagLength - 1 - flagIndex] & 0x0FF;
                        int numbersLen = calNumberPayloadLength(dataPointsItem.DataCurVal, dataPointsItem.DataResolution, 
                                dataPointsItem.DataIncrement, dataPointsItem.DataMaxVal);
                
                        byte[] resNumberValue = new byte[numbersLen];
                        System.arraycopy(numbersAndBinPayload, numbersAndBinPayloadOffset, resNumberValue, 0, numbersLen);
                        numbersAndBinPayloadOffset += numbersLen;

                        int recvNumberIntValue = bytesToIntValue(resNumberValue, numbersLen);
                        recvNumberIntValue = calNumberRealValue(Integer.toString(recvNumberIntValue), dataPointsItem.DataResolution, 
                                dataPointsItem.DataIncrement);
                        
                        String resString = String.format("%d", recvNumberIntValue);

                        LOGGER.debug("recv number string: " + resString);

                        if (((writeBitControl >> index) & 0x01) > 0) {
                            //root.put(dataPointsItem.DataPointName, Integer.toString(recvNumberIntValue));
                            root.put(dataPointsItem.DataPointName, resString);
                        }

                        index += 1;
                        if (index % 8 == 0 && index != 0) {
                            index = 0;
                            flagIndex++;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < dataPointsStruct.paramsCount; i++) {
            DataPointsItems dataPointsItem = (DataPointsItems)dataPointsStruct.paramsList.get(i);
            if (dataPointsItem != null) {
                if (dataPointsItem.RWType.equals("WRITABLE")) {
                    if (dataPointsItem.DataType.equals("BINARY")) {
                        int writeBitControl = flag[flagLength - 1 - flagIndex] & 0x0FF;
                        LOGGER.debug("writeBitControl: " + writeBitControl + " flagIndex: " + flagIndex);
                        int binLength = Integer.parseInt(dataPointsItem.DataLen);
                    
                        byte[] resBinValue = new byte[binLength];
                        System.arraycopy(numbersAndBinPayload, numbersAndBinPayloadOffset, resBinValue, 0, binLength);
                        numbersAndBinPayloadOffset += binLength;

                        String resBinValueStr = FANUtils.bytesToHexString(resBinValue);
                        LOGGER.debug("String value : " + resBinValueStr);
                        if (((writeBitControl >> index) & 0x01) > 0) {
                            root.put(dataPointsItem.DataPointName, resBinValueStr);
                        }

                        index += 1;
                        if (index % 8 == 0 && index != 0) {
                            index = 0;
                            flagIndex++;
                        }
                    }
                }
            }
        }

        return root;
    }
}
