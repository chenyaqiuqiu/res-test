package cn.wanda.iotsdk;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ConfigUtil {
	private static final Logger LOGGER = Logger.getLogger(ConfigUtil.class.getName());
    private static final String CONFIG_FILENAME="/home/chenyma/ws/temp/iot-java-sdk/src/main/resources/config.properties";
    private static boolean loaded  = false;
    private static Properties prop = new Properties(); 
    public static void loadConfig()
    {
        try{
        //	System.out.println(ConfigUtil.class.getClassLoader().getResource(CONFIG_FILENAME).getPath());
            //InputStream in =  ConfigUtil.class.getResourceAsStream(CONFIG_FILENAME);
            InputStream in =  new FileInputStream(CONFIG_FILENAME);
            prop.load(in); 
            in.close();

            loaded = true;
        }
        catch(Exception e){
            LOGGER.error(e.getMessage());
        }
    }
    public static void saveConfig()
    {
    	try{
    	 FileOutputStream out = new FileOutputStream(CONFIG_FILENAME);//true表示追加打开
         prop.store(out, "modify value");
         out.close();
    	}
    	catch(Exception e){
    		LOGGER.error(e.getMessage());
        }
    }
    public static synchronized void setProperty(String key, String value) {
    		if(!loaded)
    		{
    			loadConfig();
    		}
	    	if (prop!=null)
	    	{
                LOGGER.debug("set value: " + " key: " + key + " value: " + value);
	            prop.setProperty(key, value);
	            saveConfig();
	    	}  
    }
  
    public static synchronized boolean checkExistKey(String key) {
    	if(!loaded)
		{
			loadConfig();
		}
    	if (prop != null) {
            return prop.containsKey(key);
        }
    	else
    		return false;
    }
    
    public static synchronized String getProperty(String key) {
        return getProperty(key, (String)null);
    }

    public static synchronized String getProperty(String key, String defaultValue) {
    	
    	if(!loaded)
		{
			loadConfig();
		}
    	if (prop!=null)
         return  prop.getProperty(key, defaultValue);
    	else
    		return null;
    }
    
    public static synchronized void removeKey(String key) {
    	if(!loaded)
		{
			loadConfig();
		}
    	if (prop!=null){
            prop.remove(key);
            saveConfig();
    	}
    }

}
