package cn.wanda.iotsdk;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.zip.*;

import org.apache.log4j.Logger;


/**
 * Created by Samuel on 2016/12/27.
 */

public class FANUtils {
	private static final Logger LOGGER = Logger.getLogger(FANUtils.class.getName());
	
    public static byte[] compress(byte[] inputByte) throws IOException {
        int len = 0;
        Deflater defl = new Deflater();
        defl.setInput(inputByte);
        defl.finish();
        ByteArrayOutputStream bos = new ByteArrayOutputStream(inputByte.length);
        byte[] outputByte = new byte[inputByte.length];
        try {
            while (!defl.finished()) {
                // 压缩并将压缩后的内容输出到字节输出流bos中
                len = defl.deflate(outputByte);
                bos.write(outputByte, 0, len);
            }
            defl.end();
        } finally {
            bos.close();
        }
        return bos.toByteArray();
    }

    public static byte[] uncompress(byte[] inputByte) throws IOException {
        int len = 0;
        Inflater infl = new Inflater();
        infl.setInput(inputByte);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(inputByte.length);
        byte[] outByte = new byte[1024];
        try {
            while (!infl.finished()) {
                // 解压缩并将解压缩后的内容输出到字节输出流bos中
                len = infl.inflate(outByte);
                if (len == 0) {
                    break;
                }
                bos.write(outByte, 0, len);
            }
            infl.end();
        } catch (Exception e) {
            //
        } finally {
            bos.close();
        }
        return bos.toByteArray();
    }

    public static byte[] compressWithOpt(byte[] inputByte) throws IOException {
        int len = 0;
        Deflater defl = new Deflater();
        defl.setInput(inputByte);
        defl.finish();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] outputByte = new byte[1024];
        try {
            while (!defl.finished()) {
                // 压缩并将压缩后的内容输出到字节输出流bos中
                len = defl.deflate(outputByte);
                bos.write(outputByte, 0, len);
            }
            defl.end();
        } finally {
            bos.close();
        }

        byte[] deflData = bos.toByteArray();
        byte[] outputData;
        int compRatio = inputByte.length / deflData.length + 1;
        //System.out.println("compress ratio: " + compRatio + " compress length: " + deflData.length);

        if (deflData.length < inputByte.length && compRatio <= 0x0FF) {
            outputData = new byte[deflData.length + 1];
            outputData[0] = (byte)compRatio;
            System.arraycopy(deflData, 0, outputData, 1, deflData.length);
        } else {
            outputData = new byte[inputByte.length + 1];
            outputData[0] = (byte)1;
            System.arraycopy(inputByte, 0, outputData, 1, inputByte.length);
        }
        return outputData;
    }

    public static byte[] uncompressWithOpt(byte[] inputByte) throws IOException {
        int len = 0;
        Inflater infl = new Inflater();
        byte[] deflData;
        if (inputByte[0] > 1) {
            deflData = new byte[inputByte.length - 1];
            System.arraycopy(inputByte, 1, deflData, 0, deflData.length);
            infl.setInput(deflData);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] outByte = new byte[inputByte.length];
            try {
                while (!infl.finished()) {
                    // 解压缩并将解压缩后的内容输出到字节输出流bos中
                    len = infl.inflate(outByte);
                    if (len == 0) {
                        break;
                    }
                    bos.write(outByte, 0, len);
                }
                infl.end();
            } catch (Exception e) {
                //
            } finally {
                bos.close();
            }
            return bos.toByteArray();
        } else {
            deflData = new byte[inputByte.length - 1];
            System.arraycopy(inputByte, 1, deflData, 0, deflData.length);
            return deflData; 
        }
    }
    
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if(src != null && src.length > 0) {
            byte[] arr$ = src;
            int len$ = src.length;

            for(int i$ = 0; i$ < len$; ++i$) {
                byte b = arr$[i$];
                int v = b & 255;
                String hv = Integer.toHexString(v);
                if(hv.length() < 2) {
                    stringBuilder.append(0);
                }

                stringBuilder.append(hv);
            }

            return stringBuilder.toString();
        } else {
            return null;
        }
    }

    public static byte[] hexStringToBytes(String hexString) {
        if(hexString != null && !hexString.equals("")) {
            hexString = hexString.toUpperCase();
            int length = hexString.length() / 2;
            char[] hexChars = hexString.toCharArray();
            byte[] d = new byte[length];

            for(int i = 0; i < length; ++i) {
                int pos = i * 2;
                d[i] = (byte)(charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
            }

            return d;
        } else {
            return null;
        }
    }

    public static byte[] stringToBytes(String hexString) {
        if(hexString != null && !hexString.equals("")) {
            hexString = hexString.toUpperCase();
            char[] hexChars = hexString.toCharArray();
            int length = hexString.length();
            byte[] d = new byte[length];

            for(int i = 0; i < length; ++i) {
                d[i] = (byte)hexChars[i];
            }

            return d;
        } else {
            return null;
        }
    }

    public static String bytesToString(byte[] bytes) {
        if(bytes == null) {
            return null;
        } else {
            char[] hexChars = new char[bytes.length];

            for(int i = 0; i < bytes.length; ++i) {
                hexChars[i] = (char)bytes[i];
            }

            return String.valueOf(hexChars).toUpperCase();
        }
    }

    private static byte charToByte(char c) {
        return (byte)"0123456789ABCDEF".indexOf(c);
    }

  
    public static String getMACAddress(String interfaceName) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (interfaceName != null) {
                    if (!intf.getName().equalsIgnoreCase(interfaceName)) continue;
                }
                byte[] mac = intf.getHardwareAddress();
                if (mac==null) return "";
                StringBuilder buf = new StringBuilder();
                for (int idx=0; idx<mac.length; idx++)
                    buf.append(String.format("%02x-", mac[idx]));
                if (buf.length()>0) buf.deleteCharAt(buf.length()-1);
                return buf.toString();
            }
        } catch (Exception ex) { }
        return "";
    }
    
    public static String getMACAddressLinux(String interfaceName) {
    	String mac = null;
		try {
			Process pro = Runtime.getRuntime().exec("ifconfig "+ interfaceName);

			InputStream is = pro.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String message = br.readLine();
			int index = -1;
			
			while (message != null) {
				if ((index=message.indexOf("ether")) > 0){
					mac = message.substring(index+6, index+6+17).trim().replace(":","-").toLowerCase();
					break;
				}
				message = br.readLine();
			}
			
			br.close();
			pro.destroy();
		} catch (IOException e) {
			LOGGER.error(e.toString());
			return null;
		}
		return mac;
    }
    public static String getCPUSerial()
    {
    	String serial = null;
    	try{
    		String[] cmd={"/bin/bash", "-c", "cat /proc/cpuinfo|grep Serial|cut -d : -f 2" };
	    	Process pro = Runtime.getRuntime().exec(cmd); 
			InputStream is = pro.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			serial = br.readLine().trim();
			br.close();
			is.close();
			pro.destroy();
		} catch (IOException e) {
			LOGGER.error(e.toString());
			return null;
		}
		return serial;
    } 
    public static int getUptimeLinux()
    {
    	int uptime = 0;
    	try{
	    	FileInputStream is = new FileInputStream("/proc/uptime");
	    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String uptime_str = br.readLine();

			//LOGGER.debug("uptime_str:" + uptime_str);
			uptime_str=uptime_str.substring(0, uptime_str.indexOf("."));
			uptime= Integer.parseInt(uptime_str);
		//	LOGGER.debug("uptime:" + uptime);
			br.close();
			is.close();
    	} catch (IOException e) {
			LOGGER.error(e.toString());
		}
    	return uptime;
    }
    public static long bytesToLong(byte[] bytes) {
        return (long)((bytes[0] & 255) << 24 | (bytes[1] & 255) << 16 | (bytes[2] & 255) << 8 | bytes[3] & 255) & 4294967295L;
    }

    public static byte[] length2bytes(int length)
    {
        int  val, digit, i;
        val = length;
        i = 0;
        byte[] buf = new byte[4];
        do {
            digit = val % 128;
            val = val / 128;
            if (val > 0) digit = digit | 0x80;
            buf[i] = (byte)digit;
            i++;
        }while ((val > 0)&&(i<4));
    
        byte[] data = new byte[i];
        System.arraycopy(buf, 0, data, 0, i);
        return data;
    }
/*
    public static boolean isNetworkConnected() {
        if(AC.context != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager)AC.context.getSystemService("connectivity");
            if(mConnectivityManager == null) {
                return false;
            }

            NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
            if(mNetworkInfo != null) {
                return mNetworkInfo.isAvailable();
            }
        }

        return false;
    }

    public static byte[] getLocalIpAddress() {
        ConnectivityManager cm = (ConnectivityManager)AC.context.getSystemService("connectivity");
        if(cm == null) {
            return new byte[]{(byte)0, (byte)0, (byte)0, (byte)0};
        } else {
            NetworkInfo info = cm.getActiveNetworkInfo();
            if(info == null) {
                return new byte[]{(byte)0, (byte)0, (byte)0, (byte)0};
            } else if(info.getType() == 1) {
                WifiManager var11 = (WifiManager)AC.context.getSystemService("wifi");
                WifiInfo var12 = var11.getConnectionInfo();
                int var13 = var12.getIpAddress();
                return new byte[]{(byte)(var13 >> 24 & 255), (byte)(var13 >> 16 & 255), (byte)(var13 >> 8 & 255), (byte)(var13 & 255)};
            } else {
                if(info.getType() == 0) {
                    try {
                        Enumeration e = NetworkInterface.getNetworkInterfaces();

                        while(e.hasMoreElements()) {
                            NetworkInterface intf = (NetworkInterface)e.nextElement();
                            Enumeration enumIpAddr = intf.getInetAddresses();

                            while(enumIpAddr.hasMoreElements()) {
                                InetAddress inetAddress = (InetAddress)enumIpAddr.nextElement();
                                if(!inetAddress.isLoopbackAddress()) {
                                    String ipAddress = inetAddress.getHostAddress();
                                    String[] ips = ipAddress.split("\\.");
                                    byte[] bytes = new byte[4];

                                    for(int i = 0; i < 4; ++i) {
                                        bytes[i] = (byte)Integer.parseInt(ips[3 - i]);
                                    }

                                    return bytes;
                                }
                            }
                        }
                    } catch (Exception var10) {
                        LogUtil.d("ac_jni_android", "get local ip address failed:" + var10.toString());
                    }
                }

                return new byte[]{(byte)0, (byte)0, (byte)0, (byte)0};
            }
        }
    }*/

    public static byte[] inToBytes(InputStream in) throws Exception {
        if(in == null) {
            return null;
        } else {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();

            int ch;
            while((ch = in.read()) != -1) {
                byteStream.write(ch);
            }

            byte[] bytes = byteStream.toByteArray();
            in.close();
            byteStream.close();
            return bytes;
        }
    }

    public static byte[] intToBytes(int i) {   
        byte[] result = new byte[4];

        result[0] = (byte) (i >> 24);
        result[1] = (byte) (i >> 16);
        result[2] = (byte) (i >> 8);
        result[3] = (byte) (i /*>> 0*/);

    return result;
    }


    public static byte[] intToBytes(int data, int len) {

        byte[] result = new byte[len];

        for(int i = 0; i < len; i++) {
            result[i] = (byte)(data >> 8 * (len - 1 - i));
        }

        return result;
    } 

    public static String getBCDTime()
    {
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMMdduuhhmmssSS");
        return sdFormat.format(date);
    }
    public static String getRandomString(int length) { //length表示生成字符串的长度
        String base = "ABCDEF0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
    
    public static String getUUIDfromMAC(String mac)
    {
    	String[] mac_array = mac.split("-");
    	StringBuilder sb = new StringBuilder();
    	for (int i=0;i<mac_array.length;i++)
    	{
    		sb.append(mac_array[i]);
    	}
    	for (int i=0;i<mac_array.length;i++)
    	{
    		sb.append(mac_array[i]);
    	}
    	sb.append("00010203");
    	return sb.toString();
   }

}
