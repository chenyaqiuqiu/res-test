package cn.wanda.iotsdk;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.NoSuchAlgorithmException;

/**
 * Created by Samuel on 2017/1/4.
 */

public class FANIoTProtocol {
	private static final Logger LOGGER = Logger.getLogger(FANIoTProtocol.class.getName());
	
    public static final int DEFAULT_MSG_PRIORITY = 48;
    public static final String DEFAULT_FFAN_LINK = "1.0.0";
    public static final String DEFAULT_JSONRPC = "1.0.0";
    public static final String DEFAULT_LANG = "english";
    //构造心跳包
    public static JSONObject getHeartBeatRequest(String key, String target, String uuid, int intv_time, boolean rsp_enable, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        JSONObject params = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LOGGER.debug("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
        	LOGGER.error(ex.toString());
        }

        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            params.put("IntvTime", intv_time);
            params.put("RspEnable", rsp_enable ? 1 : 0);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "DevHeartbeat");
            all.put("Params", params);
        } catch (JSONException ignored) {
        }
        LOGGER.debug("heartbeat req=" + all.toString());
        return all;
    }
    //构造登录包
    public static JSONObject getDeviceLoginRequest(String key, String target, String uuid, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LOGGER.debug("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
        	LOGGER.error(ex.toString());
        }
        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "LoginDev");
        } catch (JSONException ignored) {
        }

        LOGGER.debug("login req=" + all.toString());
        return all;
    }
    //构造登出包
    public static JSONObject getDeviceLogoutRequest(String key, String target, String uuid, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LOGGER.debug("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
        	LOGGER.error(ex.toString());
        }
        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "LogoutDev");
        } catch (JSONException ignored) {
        }

        LOGGER.debug("logout req=" + all.toString());
        return all;
    }
    //构造注册包
    public static JSONObject getRegisterDeviceRequest(String key, String target, String uuid, String dev_name,
    												String device_model, String dev_type,  String dev_category,
    												String manu_date, String device_sn, String mac, String vendor_flag, 
    												String sw_ver, String hw_ver, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject params = new JSONObject();
        JSONObject system = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LOGGER.debug("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
            LOGGER.error(ex.toString());
        }

        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            params.put("DevName", dev_name);
            params.put("Device_Model", device_model);
            params.put("DevType", dev_type);
            params.put("DevCategory", dev_category);
            params.put("ManuDate", manu_date);
            params.put("Device_SN", device_sn);
            params.put("MAC", mac);
            params.put("Vendor_Flag", vendor_flag);
            params.put("swVer", sw_ver);
            params.put("hwVer", hw_ver);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "RegisterDev");
            all.put("Params", params);
        } catch (JSONException ignored) {
        }

        LOGGER.debug("register device req=" + all.toString());
        return all;
    }

        //构造用户信息包
    public static String getUserRequest(String uuid,String method, JSONObject params,  int msg_priority, int msg_id) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        String key = FANUtils.getRandomString(32);
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:ffanLink.wanda.cn");
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }

        try {
            request.put("UUID", uuid);
            request.put("Target", "ffanLink.wanda.cn");
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);

            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", method);
            all.put("Params", params);
            all.put("MsgID", msg_id);
        } catch (JSONException ignored) {
        }

        //LOGGER.debug("user device req=" + all.toString());
        return all.toString();
    }
}

