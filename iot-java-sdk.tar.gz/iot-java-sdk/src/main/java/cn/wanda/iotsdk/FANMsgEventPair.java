package cn.wanda.iotsdk;

public class FANMsgEventPair {
	private FANEventHandler mEventHandler;
	private int mMsgID;
	private String mUuid;
	
	public FANMsgEventPair(FANEventHandler e, int m)
	{
		mEventHandler = e;
		mMsgID = m;
	}
	
	public int getMsgID()
	{
		return mMsgID;
	}
	public FANEventHandler getEventHandler()
	{
		return mEventHandler;
	}
	public String getUuid()
	{
		return mUuid;
	}
	public void setUuid(String m)
	{
		mUuid = m;
	}
	public void setMsgID(int m)
	{
		mMsgID = m;
	}
	public void setFANEventHandler(FANEventHandler e)
	{
		mEventHandler = e;
	}
}
