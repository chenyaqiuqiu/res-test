package cn.wanda.iotsdk;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;


public class FANDidRegister {
	private static final Logger LOGGER = Logger.getLogger(FANDidRegister.class.getName());
	private static final String REQUEST_PATH = "/dev/%s/device";
	private String pk;
	private String pk_secret;
	private String mac;
	private String did;
	private String host;
	private String mqttUrl;
	private String nosslPort;
	private String sslPort;

	public FANDidRegister(String pk, String pk_secret, String mac, String host)
	{	
		this.pk=pk;
		this.pk_secret=pk_secret;
		this.mac=mac;
		this.host=host;
	}

	public int register()
	{
		String didSaved = ConfigUtil.getProperty("did");

        if (didSaved != null && !didSaved.isEmpty()) {
        	this.did = didSaved;
        	return 0;
        }

		try
		{
			String url_request=String.format(REQUEST_PATH,  pk);

			String httpHeader;
			String sslSaved = ConfigUtil.getProperty("use_ssl");
			if (sslSaved != null && sslSaved.equals("true")) {
				httpHeader = "https";
			} else {
				httpHeader = "http";
			}

			URL url = new URL(httpHeader, host, url_request);
			LOGGER.debug("url:"+ url.toString());
			
			System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
			
			String content = String.format("mac=%s&passcode=%s&type=normal",mac, pk.substring(0, 10));
			LOGGER.debug("content:"+content);
			
	        SecretKeySpec key = new SecretKeySpec(FANUtils.hexStringToBytes(pk_secret), "AES");
	        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding"); // 创建密码器  
	        cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化  
	        byte[] encrypt_data =  cipher.doFinal(content.getBytes());

	        // this is due to jizhiyun use non-standard encrypt code
	        // fix this issue
	        byte[] encrypt_final_data = encrypt_data;

	        String smartCloudEncryptMode = ConfigUtil.getProperty("smartCloudEncryptMode");
	        if (smartCloudEncryptMode != null && smartCloudEncryptMode.equals("true")) {
	        	int encryt_data_block_offset = content.length() % 16;
	        	if (encryt_data_block_offset == 0) {
	        		LOGGER.debug(" reduce last 16 bytes padding data ");
	        		encrypt_final_data = new byte[encrypt_data.length - 16];
	        		System.arraycopy(encrypt_data, 0, encrypt_final_data, 0, encrypt_final_data.length);
	        	} else {
	        		encrypt_final_data = encrypt_data;
	        	}
	        }

			LOGGER.debug(" encrypt_final_data length: " + encrypt_final_data.length + " content length:" + content.length());
	        String encrypt_string = FANUtils.bytesToHexString(encrypt_final_data);

	        String post_data = "data="+encrypt_string;
	        byte[] post_buf=post_data.getBytes();
	        
	        LOGGER.debug("post_data:"+post_data);
	        
			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setAllowUserInteraction(true);
	        httpConn.setConnectTimeout(3000); // 设置发起连接的等待时间，3s
	        httpConn.setReadTimeout(10000); // 设置数据读取超时的时间，10s
	        httpConn.setUseCaches(false); // 设置不使用缓存
	        httpConn.setDoOutput(true);
	        httpConn.setRequestMethod("POST");
	        httpConn.setDoInput(true);
	        httpConn.setRequestProperty("Host", host);
	        httpConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        httpConn.setRequestProperty("Content-Length", Integer.toString(post_buf.length));
	        
	      //  System.out.println("content_send:" + content_send);
	        OutputStream os = httpConn.getOutputStream();
	        BufferedOutputStream bos = new BufferedOutputStream(os);
	        	         
	        bos.write(post_buf);
	        bos.flush();
	       
	      //  System.out.println("httpConn.getResponseCode():"+httpConn.getResponseCode());
	
	        StringBuffer strBuf = new StringBuffer();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(
	                httpConn.getInputStream()));
	        String line = null;
	        while ((line = reader.readLine()) != null) {
	            strBuf.append(line);
	        }
	        String res = strBuf.toString();
	        System.out.println(res);
	        
	        bos.close();
	        os.close();
	        reader.close();
	        cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");  
	        cipher.init(Cipher.DECRYPT_MODE, key); 
	        byte[] res_data = FANUtils.hexStringToBytes(res);
	        byte[] decrypt_data = cipher.doFinal(res_data);  
	        String decrypt_str = new String(decrypt_data);
	        LOGGER.debug("decrypt:" + decrypt_str);
	        if(decrypt_str.startsWith("did="))
	        {
	        	did = decrypt_str.substring(4,26);
	        	return 0;
	        }
       
		}
		catch(Exception ex)
		{
			LOGGER.error(ex.getMessage());
		}
		
		return -1;
	}
	
	public int provision()
	{
		try
		{
			
			System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
		
			String content = did;
			LOGGER.debug("content:"+content);
	        SecretKeySpec key = new SecretKeySpec(FANUtils.hexStringToBytes(pk_secret), "AES");  
	        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding"); // 创建密码器  
	        cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化  
	        byte[] encrypt_data =  cipher.doFinal(content.getBytes()); 
	        	        // this is due to jizhiyun use unstandent decrypt code
	        byte[] encrypt_final_data;
	        int encryt_data_block_offset = content.length() % 16;
	        if (encryt_data_block_offset == 0) {
	        	LOGGER.debug(" reduce last 16 bytes padding data");
	        	encrypt_final_data = new byte[encrypt_data.length - 16];
	        	System.arraycopy(encrypt_data, 0, encrypt_final_data, 0, encrypt_final_data.length);
	        } else {
	        	encrypt_final_data = encrypt_data;
	        }

			LOGGER.debug(" encrypt_final_data length: " + encrypt_final_data.length + " content length:" + content.length());

	        String encrypt_string = FANUtils.bytesToHexString(encrypt_final_data);
	        String url_request = "/dev/" + pk + "/device?did=" + encrypt_string;
			
			String httpHeader;
			String sslSet = ConfigUtil.getProperty("use_ssl");
			if (sslSet != null && sslSet.equals("true")) {
				url_request = url_request + "&tls=1";
				httpHeader = "https";
			} else {
				httpHeader = "http";
			}

			URL url = new URL(httpHeader, host, url_request);
			LOGGER.debug("url:"+ url.toString());
	        
			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setAllowUserInteraction(true);
	        httpConn.setConnectTimeout(3000); // 设置发起连接的等待时间，3s
	        httpConn.setReadTimeout(10000); // 设置数据读取超时的时间，10s
	        httpConn.setUseCaches(false); // 设置不使用缓存
	        httpConn.setDoOutput(true);
	        httpConn.setRequestMethod("GET");
	        httpConn.setDoInput(true);
	        httpConn.setRequestProperty("Host", host);
	        httpConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	
	        StringBuffer strBuf = new StringBuffer();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(
	                httpConn.getInputStream()));
	        
	        String line = null;
	        while ((line = reader.readLine()) != null) {
	            strBuf.append(line);
	        }

	        String res = strBuf.toString();

	        System.out.println("provision recv: " + res);
	        
	        reader.close();
	        
	        cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");  
	        cipher.init(Cipher.DECRYPT_MODE, key); 
	        byte[] res_data = FANUtils.hexStringToBytes(res);
	        byte[] decrypt_data = cipher.doFinal(res_data);  
	        String decrypt_str = new String(decrypt_data);

	        String[] recvResult = decrypt_str.split("&");
	        String[] recvMqttUrl = recvResult[0].split("=");
	        String[] recvPort = recvResult[1].split("=");
	        
	        if (sslSet != null && sslSet.equals("true")) {
				String recvsslPort[] = recvResult[7].split("=");
				sslPort = recvsslPort[1];
			}

	        mqttUrl = recvMqttUrl[1];
	        nosslPort = recvPort[1];
	        // host=iotsandbox.ffan.com&port=10003&server_ts=1503306662&log_host=127.0.0.1&log_port=8080&biz_log=0&sys_log=0
	        // host=iotm2m.uat.ffan.com&port=10003&server_ts=1505115859&log_host=127.0.0.1&log_port=8080&biz_log=0&sys_log=0&port_s=10103
	        LOGGER.debug("decrypt:" + decrypt_str + " mqttUrl: " + mqttUrl + " nosslPort: " + nosslPort + " sslport: " + sslPort);
		}
		catch(Exception ex)
		{
			LOGGER.error(ex.getMessage());
		}
		
		return -1;
	}

	public String getDid()
	{
		return did;
	}

	public String getMqttUrl() {
		return mqttUrl;
	}

	public String getMqttPort() {
		String sslSet = ConfigUtil.getProperty("use_ssl");
	    if (sslSet != null && sslSet.equals("true")) {
			return sslPort;
		} else {
			return nosslPort;
		}
	}
}
