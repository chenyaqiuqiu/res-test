package cn.wanda.iotsdk;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Created by Samuel on 2017/2/21.
 */

public class FANIoTSession extends Thread implements FANEventHandler, Runnable {
	private static final Logger LOGGER = Logger.getLogger(FANIoTSession.class.getName());
    private static final int SESSION_TIMEOUT_INTERVAL  = 10000; //10s
    //运行状态
    public static final int STATE_DISCONNECT = 0;
    public static final int STATE_REGISTER = 1;
    public static final int STATE_LOGIN = 2;
    public static final int STATE_NORMAL = 3;

    //会话事件
    private static final int SESSION_EVENT_CONNECTED = 0x1; //连接到IoT服务器
    private static final int SESSION_EVENT_REGISTERED = 0x2; //已注册
    private static final int SESSION_EVENT_LOGINED = 0x4;  //已登录
    private static final int SESSION_EVENT_DISCONNECTED = 0x8; //断线
    private static final int SESSION_EVENT_TIMEOUT = 0x10; //超时

    //状态变量
    private int mState = STATE_DISCONNECT;

    //会话线程运行标志
    private boolean mSessionRunning;
    //会话事件标志
    private int mSessionEvent = 0;
    //锁
    private Lock mLock = new ReentrantLock();
    //条件
    private Condition mCondition = mLock.newCondition();
    //业务心跳间隔
    private int mHeartbeatInterval;
 
    //设备类
    private FANIoTDevice mDev;
    private FANUserMsgHandler mUserMsgHandler;
    private FANIoTClient mIoTClient;

    private void verifyDeviceParams(FANIoTDevice d) {
        if ((d.getDevCategory()==null) || (d.getDevCategory().isEmpty()))
        {
            LOGGER.fatal("error device: missing DevCategory");
            System.exit(-1);
        }

        if ((d.getDevice_Model()==null) || (d.getDevice_Model().isEmpty()))
        {
            LOGGER.fatal("error device: missing Device_Model");
            System.exit(-1);
        }

        if ((d.getDevice_SN()==null) || (d.getDevice_SN().isEmpty()))
        {
            LOGGER.fatal("error device: missing Device_SN");
            System.exit(-1);
        }

        if ((d.getDevName()==null) || (d.getDevName().isEmpty()))
        {
            LOGGER.fatal("error device: missing DevName");
            System.exit(-1);
        }

        if ((d.getDevType()==null) || (d.getDevType().isEmpty()))
        {
            LOGGER.fatal("error device: missing DevType");
            System.exit(-1);
        } 

        if ((d.gethwVer()==null) || (d.gethwVer().isEmpty()))
        {
            LOGGER.fatal("error device: missing hwVer");
            System.exit(-1);
        } 

        if ((d.getMac()==null) || (d.getMac().isEmpty()))
        {
            LOGGER.fatal("error device: missing Mac");
            System.exit(-1);
        }   
        if ((d.getManuDate()==null) || (d.getManuDate().isEmpty()))
        {
            LOGGER.fatal("error device: missing ManuDate");
            System.exit(-1);
        } 

        if ((d.getswVer()==null) || (d.getswVer().isEmpty()))
        {
            LOGGER.fatal("error device: missing swVer");
            System.exit(-1);
        }

        if ((d.getUUID()==null) || (d.getUUID().isEmpty()))
        {
            LOGGER.warn("warn device: missing UUID");
        //  System.exit(-1);
        }

        if ((d.getVendor_Flag()==null) || (d.getVendor_Flag().isEmpty()))
        {
            LOGGER.fatal("error device: missing Vendor_Flag");
            System.exit(-1);
        }
    }

    public FANIoTSession(FANIoTDevice d, FANUserMsgHandler h, FANIoTClient c, int heartBeatInterval)
    {
        verifyDeviceParams(d);

        mDev = d;
        mUserMsgHandler = h;
        mIoTClient = c;
        mHeartbeatInterval = heartBeatInterval;

        mIoTClient.addEventHandler(this);
    }
    
    @Override
    public void run()
    {
        long wait_time_start = System.currentTimeMillis();
        long heartbeat_time = wait_time_start;
        mSessionRunning = true;
        int event= 0;

        while (mSessionRunning) {
            mLock.lock();
            while (mSessionEvent == 0) {
                //等待Event事件
            	try {
            		mCondition.await(1, TimeUnit.SECONDS);
            	}
                catch(InterruptedException ex)
                {
                	break;
                }
            	if ((mState==STATE_DISCONNECT) && (mIoTClient.getConnected()))
            	{
            		break;
            	}
                if (mSessionEvent == 0) {
                    long now = System.currentTimeMillis();
                    if( now - wait_time_start > SESSION_TIMEOUT_INTERVAL) {
                        //超时
                        mSessionEvent = SESSION_EVENT_TIMEOUT;
                        wait_time_start = now;
                        break;
                    }
                }
            }
            event = mSessionEvent;
            mLock.unlock();
	       
	        //    LOGGER.debug( "mState: " + mState + " mSessionEvent: " + mSessionEvent);
            int next_state = mState;
            switch(mState)
            {
                case STATE_DISCONNECT:
                	if ((event & SESSION_EVENT_CONNECTED) > 0 || mIoTClient.getConnected())
                	{
                        boolean registered = Boolean.parseBoolean(ConfigUtil.getProperty("registered_"+ mDev.getMac()));
                        if (registered) {
                            String uuid = ConfigUtil.getProperty("UUID_"+ mDev.getMac());
                            if ((uuid==null) || (uuid.isEmpty())) {
                                //注册设备
                                next_state = STATE_REGISTER;
                                registerDevice();
                            } else {
                                mDev.setUUID(uuid);
                                //已注册
                                next_state  = STATE_LOGIN;
                                loginDevice();
                            }
                        } else {
                            //注册设备
                            next_state = STATE_REGISTER;
                            registerDevice();
                        }
                	}
                    break;
                case STATE_REGISTER:
                    //注册成功事件
                    if ((event & SESSION_EVENT_REGISTERED) > 0)
                    {
                        next_state = STATE_LOGIN;
                        loginDevice();
                    }
                    //断线事件
                    else if ((event & SESSION_EVENT_DISCONNECTED) > 0)
                    {
                        next_state = STATE_DISCONNECT;
                    }
                    //超时事件
                    else if ((event & SESSION_EVENT_TIMEOUT) > 0)
                    {
                        next_state = STATE_REGISTER;
                        registerDevice();
                    }
                    break;
                case STATE_LOGIN:
                    //已登录事件
                    if ((event & SESSION_EVENT_LOGINED) > 0)
                    {
                        next_state = STATE_NORMAL;
                    }
                    //断线事件
                    else if ((event & SESSION_EVENT_DISCONNECTED)>0)
                    {
                        next_state = STATE_DISCONNECT;
                    }
                    //超时事件
                    else if ((event & SESSION_EVENT_TIMEOUT)>0)
                    {
                        next_state = STATE_LOGIN;
                    	loginDevice();
                    }
                    break;
                case STATE_NORMAL:
                    if ((event & SESSION_EVENT_TIMEOUT)>0)
                    {
                    	//check hartbeat
                        long now = System.currentTimeMillis();
                        if( (now - heartbeat_time) > (mHeartbeatInterval * 1000)) 
                        {
                        	heartbeatDevice();
                            heartbeat_time = now;
                        }
                    }
                    //断线事件
                    else if ((event & SESSION_EVENT_DISCONNECTED)>0)
                    {
                        next_state = STATE_DISCONNECT;
                    }
                    break;
                default:
                    break;
	            }
	            mState = next_state;
	            mLock.lock();
	            mSessionEvent = 0;
	            mLock.unlock();
            }
        LOGGER.debug("exit Session Thread");
    }
    //设置会话事件
    private void raiseSessionEvent(int ev)
    {
        mLock.lock();
        try {
            mSessionEvent |= ev;
            mCondition.signal();
        }
        finally {
            mLock.unlock();
        }
    }

    //获取当前的会话状态
    public  int getSessionState()
    {
        return mState;
    }


    //设定业务心跳间隔
    //val 心跳间隔单位秒
    public void setHeartbeatInterval(int val)
    {
        mHeartbeatInterval = val;
    }
    
    //处理IoT服务器回复的消息
    @Override
    public void handleMsg(JSONObject msg)
    {
        JSONObject result;
        int resultCode = 0;
        try {
            result = msg.getJSONObject("Result");
            resultCode = result.getInt("Code");
	        LOGGER.debug( "handleMsg " + msg.toString());

	        if (mState == STATE_REGISTER) {
	            if (resultCode == 1000 || resultCode == 3028) {
                    if (resultCode == 1000) {
	                   LOGGER.debug(mDev.getMac() + " register ok");
                   } else {
                        LOGGER.debug(mDev.getMac() + " register already registered");
                   }
	                
                    String uuid = result.getJSONObject("Data").getString("UUID");
	                String mac = result.getJSONObject("Data").getString("MAC");

	                if (!mac.equalsIgnoreCase(mDev.getMac()))
	                {
	                	LOGGER.error("mac not same");
	                }
	                
                    mDev.setUUID(uuid);
                    mIoTClient.setEventHandlerUuid(this, uuid);
                    
                    //ConfigUtil.setProperty("UUID_"+ mac, uuid);
                    //ConfigUtil.setProperty("registered_"+  mac, "true");

	                raiseSessionEvent(SESSION_EVENT_REGISTERED);

	            } else {
	                LOGGER.error(mDev.getMac() + " register failed");
	            }
	        } else if (mState == STATE_LOGIN) {
	                if (resultCode == 1000) {
	                    LOGGER.debug(mDev.getMac() + " login successful");
	                    raiseSessionEvent(SESSION_EVENT_LOGINED);
                        if (mUserMsgHandler != null) {
                            mUserMsgHandler.logined();
                        }
	                } else {
	                    LOGGER.error(mDev.getMac() + " login failed");
	                }
	          
	        } else if (mState == STATE_NORMAL) {
	            //由上层处理用户msg
	            if ((mUserMsgHandler != null) && (msg != null))
	            {
	            	mUserMsgHandler.handleMsg(msg);
	            }
	        }
        } catch (JSONException ex) {
        }
    }

    //处理IoT回调，已连接服务器
    @Override
    public void connected()
    {
        raiseSessionEvent(SESSION_EVENT_CONNECTED);
    }
    //处理IoT回调，已断开服务器
    @Override
    public void disconnected()
    {
        raiseSessionEvent(SESSION_EVENT_DISCONNECTED);
    }
    
    public void logoutSession() {
        //logoutDevice();
        //next_state = STATE_DISCONNECT;
    }

    private void clientSendTsData(byte[] payload) {
        mIoTClient.sendTransparentData(payload);

    }

    public void reportDeviceMsg(String method, JSONObject params) {
        try {
            synchronized(this)
            {
                int messageId = mIoTClient.getUniqueMessageId();
                mIoTClient.setEventHandlerMessageId(this, messageId);

                String userMessage = FANIoTProtocol.getUserRequest(mDev.getUUID(), 
                                method, params, FANIoTProtocol.DEFAULT_MSG_PRIORITY, messageId);
                
                //LOGGER.debug("send: " + userMessage);
                
                byte[] payload = userMessage.getBytes("utf-8");
                clientSendTsData(payload);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString());
        }
    }

    public void reportDeviceMsg(JSONObject msg) {
        try {
            synchronized(this)
            {
                int messageId = mIoTClient.getUniqueMessageId();
                msg.put("MsgID", messageId);
                mIoTClient.setEventHandlerMessageId(this, messageId);

                //LOGGER.debug("send: " + msg.toString());
                
                byte[] payload = msg.toString().getBytes("utf-8");
                clientSendTsData(payload);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString());
        }
    }
    
    public void reportDeviceResponse(JSONObject msg) {
        try {
            synchronized(this)
            {
                //LOGGER.debug("send: " + msg.toString());
                byte[] payload = msg.toString().getBytes("utf-8");
                clientSendTsData(payload);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString());
        }
    }

    //发送心跳包
    private void heartbeatDevice() {
        LOGGER.debug("heartbeatDevice " + mDev.getMac());

        JSONObject heart_beat_req = FANIoTProtocol.getHeartBeatRequest(mIoTClient.getPK(), mIoTClient.getTarget(),
        		mDev.getUUID(), mHeartbeatInterval, false, FANIoTProtocol.DEFAULT_MSG_PRIORITY);

        reportDeviceMsg(heart_beat_req);
    }

    //发送设备登录
    private void loginDevice() {
        LOGGER.debug("loginDevice "  + mDev.getMac());

        JSONObject login_device_req = FANIoTProtocol.getDeviceLoginRequest(mIoTClient.getPK(), mIoTClient.getTarget(),
        		mDev.getUUID(), FANIoTProtocol.DEFAULT_MSG_PRIORITY);
        
        reportDeviceMsg(login_device_req);
    }

    //发送注册设备
    private void registerDevice() {
        LOGGER.debug("registerDevice "  + mDev.getMac());

        JSONObject register_device_req = FANIoTProtocol.getRegisterDeviceRequest(mIoTClient.getPK(), mIoTClient.getTarget(),
        		mDev.getUUID(),mDev.getDevName(),mDev.getDevice_Model(),mDev.getDevType(),
                mDev.getDevCategory(), mDev.getManuDate(),mDev.getDevice_SN(),mDev.getMac(),mDev.getVendor_Flag(),mDev.getswVer(),mDev.gethwVer(),
                FANIoTProtocol.DEFAULT_MSG_PRIORITY);

        reportDeviceMsg(register_device_req);
    }
    //发送设备登出
    private void logoutDevice() {
        LOGGER.debug("logoutDevice "  + mDev.getMac());

        JSONObject logout_device_req = FANIoTProtocol.getDeviceLogoutRequest(mIoTClient.getPK(), mIoTClient.getTarget(), 
            mDev.getUUID(),  FANIoTProtocol.DEFAULT_MSG_PRIORITY);
       
        reportDeviceMsg(logout_device_req);
    }

    public String getUserRequest(String method, JSONObject params) {
        int msg_id = mIoTClient.getUniqueMessageId();
        String user_msg = FANIoTProtocol.getUserRequest(mDev.getUUID(), method, params, FANIoTProtocol.DEFAULT_MSG_PRIORITY, msg_id);
        return user_msg;
    }

    //销毁会话对象
    protected void finalize()
    {
        LOGGER.debug("FANIoTSession finalize");
        try
        {
            mSessionRunning = false;
            logoutDevice();
            raiseSessionEvent(SESSION_EVENT_DISCONNECTED);
            interrupt();
            join();
            LOGGER.debug("FANIoTSession Thread joined");
        }
        catch(Exception ex)
        {
            LOGGER.error(ex.toString());
        }
        
    }

}
