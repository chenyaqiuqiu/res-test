package cn.wanda.iotsdk;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by Samuel on 2017/2/21.
 */

public class FANIoTDevice {
    private String DevName;
    private String Device_Model;
    private String DevType;
    private String DevCategory;
    private String UUID;
    private String ManuDate;
    private String Device_SN;
    private String MAC;
    private String Vendor_Flag;
    private String swVer;
    private String hwVer;
    private int heartbeat;
    private boolean trace_heartbeat = false;
 
  	public Lock mLock = new ReentrantLock(); //锁
  	
    public String getDevName(){return DevName;}
    public void setDevName(String DevName){this.DevName = DevName;}

    public String getDevice_Model(){return Device_Model;}
    public void setDevice_Model(String Device_Model){this.Device_Model=Device_Model;}

    public String getDevType(){return DevType;}
    public void setDevType(String DevType){this.DevType=DevType;}

    public String getDevCategory(){return DevCategory;}
    public void setDevCategory(String DevCategory){this.DevCategory=DevCategory;}

    public String getUUID(){return UUID;}
    public void setUUID(String UUID){this.UUID=UUID;}

    public String getManuDate(){return ManuDate;}
    public void setManuDate(String ManuDate){this.ManuDate=ManuDate;}

    public String getMac(){return MAC;}
    public void setMAC(String MAC){this.MAC=MAC;}

    public String getDevice_SN(){return Device_SN;}
    public void setDevice_SN(String Device_SN){this.Device_SN=Device_SN;}

    public String getVendor_Flag(){return Vendor_Flag;}
    public void setVendor_Flag(String Vendor_Flag){this.Vendor_Flag=Vendor_Flag;}

    public String getswVer(){return  swVer;}
    public void setswVer(String swVer){this.swVer=swVer;}

    public String gethwVer(){return  hwVer;}
    public void sethwVer(String hwVer){this.hwVer=hwVer;}

    //public int getheartbeat(){return  this.heartbeat;}
    //public void setheartbeat(int heartbeat){this.heartbeat=heartbeat;}
    //public void trig_heartbeat(){this.heartbeat++;}
    //public void clear_heartbeat(){this.heartbeat=0;}

    //public boolean get_trace_heartbeat(){return this.trace_heartbeat;}
    //public void set_trace_heartbeat(boolean t){this.trace_heartbeat=t;}
}
