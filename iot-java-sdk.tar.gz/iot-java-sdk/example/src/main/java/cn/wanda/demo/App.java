package cn.wanda.demo;

import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.wanda.iotsdk.FANUtils;


/**
 * Hello world!
 *
 */

public class App 
{
	private static void setLoggerProperty() {
	    Properties prop = new Properties();
		prop.setProperty("log4j.rootLogger", "DEBUG, syslog, console");
		prop.setProperty("log4j.appender.syslog", "org.apache.log4j.net.SyslogAppender");
		prop.setProperty("log4j.appender.syslog.SyslogHost", "127.0.0.1");
		prop.setProperty("log4j.appender.syslog.Facility", "user");
		prop.setProperty("log4j.appender.syslog.layout", "org.apache.log4j.PatternLayout");
		prop.setProperty("log4j.appender.syslog.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
		
		prop.setProperty("log4j.appender.console", "org.apache.log4j.ConsoleAppender");
		prop.setProperty("log4j.appender.console.Target", "System.out");
		prop.setProperty("log4j.appender.console.layout", "org.apache.log4j.PatternLayout");
		prop.setProperty("log4j.appender.console.layout.ConversionPattern", "%d [%t] %p %c [%L] - %m %n");
		
		PropertyConfigurator.configure(prop);
		Logger logger = Logger.getLogger(App.class);  
		logger.setLevel(Level.DEBUG);
	}

    public static void main( String[] args )
    {
		setLoggerProperty();

		int macNumber = 10;

		for (int i = 0; i < 100; i++) {
			String mac = String.format("%012d", macNumber++);
			StringBuilder  sb = new StringBuilder (mac);  
			sb.insert(10, "-");  
			sb.insert(8, "-");  
			sb.insert(6, "-");  
			sb.insert(4, "-");  
			sb.insert(2, "-");  
			mac = sb.toString();  

    		Device customerDevice = new Device(mac);

  
    		Runtime.getRuntime().addShutdownHook(new Thread(){
				public void run() {
					customerDevice.finalize();
				}
			});

    		customerDevice.start();
		}
    }
}
