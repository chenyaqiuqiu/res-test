package cn.wanda.demo;


import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

import java.text.SimpleDateFormat; 
import java.util.Locale;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import cn.wanda.iotsdk.FANIoTDevice;
import cn.wanda.iotsdk.FANIoTSDK;
import cn.wanda.iotsdk.FANIoTSession;
import cn.wanda.iotsdk.FANIoTClient;
import cn.wanda.iotsdk.FANUserMsgHandler;
import cn.wanda.iotsdk.FANDataPointListener;
import cn.wanda.iotsdk.FANOtaListener;
import cn.wanda.iotsdk.FANUtils;
import cn.wanda.iotsdk.ConfigUtil;
import cn.wanda.iotsdk.ConfigUtilTest;
import cn.wanda.iotsdk.FANIoTProtocol;
import cn.wanda.iotsdk.FANIoTHttpChannel;

public class Device extends Thread implements Runnable, FANUserMsgHandler, FANDataPointListener, FANOtaListener{
	private static final Logger LOGGER = Logger.getLogger(Device.class.getName());
	public static final int DEVDATA_HEARTBEAT_INTERVAL = 180; //180s

	FANIoTSDK mIoTSDK;
	FANIoTDevice device;
	FANIoTClient iotClient;
	FANIoTSession deviceSession;
	private String deviceMac;
	private JSONObject cameraData;
	
	private boolean deviceIsReady = false;
	private boolean running = true;

        // test
    private long camSumSendTime = 0;
    private long camSendTimes = 0;
    private long camLostResponseTimes = 0;
    private long camSendSysTime = 0;

    private boolean camHasResponse = true;

    private long beaconSumSendTime = 0;
    private long beaconSendTimes = 0;
    private long beaconLostResponseTimes = 0;
    private long beaconSendSysTime = 0;

    private boolean beaconHasResponse = true;

    private long sumSendTime = 0;
    private long sendTimes = 0;
    private long lostResponseTimes = 0;
    private long sendSysTime = 0;

    private boolean hasResponse = true;


	private class AnalysisData {
    public int age;
    public int gender;
    public long startTime;
    public int interval;
    public int quality;
    public int imageSize;
    public byte[] imageData;
    public int id;
    public int flag; //1中间上报，0离开上报

    public int left;
    public int top;
    public int right;
    public int bottom;
    public int count; // 统计次数
    public int countQuality;
    public int countWitdh;
    public int countHeight;
    public long lastUpdateTime;
}

public Device (String mac) {
	deviceMac = mac;
}

private class CameraDataResult {

    private int status;
    private int MsgID;
    private String UUID;
    //private ServerResult Result;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getMsgID() {
        return MsgID;
    }

    public void setMsgID(int msgID) {
        MsgID = msgID;
    }

    public String getUUID() {
        return UUID;
    }

    public void setUUID(String UUID) {
        this.UUID = UUID;
    }
/*
    public ServerResult getResult() {
        return Result;
    }

    public void setResult(ServerResult result) {
        Result = result;
    }
    */
}


 
	public void run()
	{
		mIoTSDK = new FANIoTSDK(deviceMac);

		iotClient = mIoTSDK.getIoTClient();
		iotClient.setDataPointListener(this);
		iotClient.setOtaListener(this);

    	device = new FANIoTDevice();
		 
		device.setDevName(deviceMac);
		device.setDevType("SMARTADM_MODEL.0");
		device.setDevCategory("SMARTADM");
		device.setDevice_Model("SMARTADM-DEBUG");
		device.setManuDate("2017-06-12");
		//device.setDevice_SN(FANUtils.getCPUSerial());
		device.setDevice_SN("1234567890");
		device.setVendor_Flag("WANDA_FEIFAN");
		device.setswVer(ConfigUtil.getProperty("sw_version"));
		device.sethwVer(ConfigUtil.getProperty("hw_version"));
		device.setMAC(deviceMac);
		device.setUUID("");
		
		mIoTSDK.addDevice(device, this, DEVDATA_HEARTBEAT_INTERVAL);
		
		deviceSession = mIoTSDK.getDeviceSession(device);

		while(running) {
			if (deviceIsReady) {
			// here your code
				//LOGGER.debug(" ready to run ");
				//reportBeaconData();
			}
	    	try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			}
		}
	}

	@Override
	public void handleMsg(JSONObject msg) {
		// TODO Auto-generated method stub
        LOGGER.debug("<--- recive new MQTT meaage --->");
        hasResponse = true;
        long time = System.currentTimeMillis();
        sumSendTime += time - sendSysTime;
	}

	public boolean onRevDataPoint(String key, byte[] value) {
		// handle writable datapoint recv
		return true;
	}

	public void onOtaMessage(String version, String url) {
		// get your image from url and do update
		LOGGER.debug("user recv ota message: " + url + " swVersion: " + version);
	}

	public void logined() {
		LOGGER.debug(" --- device login --- ");
		deviceIsReady = true;
		resendCameraData();
		//reportBeaconLog();

		// dataPoints usage
		//iotClient.updateDataPoint("name", "123");
		//iotClient.syncDataPoint();

		// customer json report
		//JSONObject msg = new JSONObject();
		//msg.put("message", 1);
		//deviceSession.reportDeviceMsg(msg);
	}

    private AnalysisData readObjFromFile(String fileName) {
        try {
        	int index = 0;
        	File image = new File(fileName);
        	InputStream in = new FileInputStream(image);
        	byte[] imageData = new byte[(int)image.length()];
        	in.read(imageData);
        	in.close();

            AnalysisData data = new AnalysisData();
            data.imageData = imageData;
            data.id = index++;
            data.imageSize = imageData.length;
            data.gender = 1;
            data.flag = 0;

            return data;
        } catch (Exception e) {
        	LOGGER.error("read obj error: " + e.toString());
        }
        return null;
    }

   private void resendCameraData() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                	//String picDir = ConfigUtil.getProperty("pics");
                    File baseDir = new File("/home/chenyma/ws/temp/iot-java-sdk/example/pics");

                    File[] allFiles = baseDir.listFiles();
                    for (int i = 0; i < allFiles.length; i++) {
                        final File temp = allFiles[i];
						LOGGER.debug("allFiles length: " + temp.getAbsolutePath());

                        final AnalysisData data = readObjFromFile(temp.getAbsolutePath());
                        if (data != null) {
                            Callback callback = new Callback() {
                                @Override
                                public void onFailure(Call call, IOException e) {
                                    LOGGER.debug("resendCameraData onFailure faceid " + data.id + e);
                                }

                                @Override
                                public void onResponse(Call call, Response response) throws IOException {
                                    try {
                                        camHasResponse = true;
                                        long time = System.currentTimeMillis();
                                        camSumSendTime = camSumSendTime + time - camSendSysTime;

                                        String bodyStr = response.body().string();
                                        LOGGER.debug("resendCameraData onResponse faceid " + bodyStr);

                                    } catch (Exception e) {
                                        LOGGER.debug("resendCameraData onResponse" + e);
                                    }
                                }
                            };

                            if (camHasResponse == false) {
                                // do not receive response
                                camLostResponseTimes++;
                                LOGGER.debug("<--- http lost sending face response --->");
                            }
                            camSendTimes++;
                            camHasResponse = false;
                            LOGGER.debug("camSumSendTime: " + camSumSendTime + " camLostResponseTimes: " + camLostResponseTimes + " camSendTimes: " + camSendTimes);

                            sendCameraData(data, callback);
                            
                            camSendSysTime = System.currentTimeMillis();
                            Thread.sleep(1000 * 10);
                        } else {
                        	LOGGER.debug("file data is null");
                        }
                    }

                } catch (Exception e) {

                }
            }
        }).start();
    }


    private void sendCameraData(final AnalysisData data, Callback callback) {
        LOGGER.debug("sendCameraData FaceID " + data.id +
                " Gender " + data.gender + " Age " + data.age + " FaceStatus "
                + data.flag);
        //step 2 send cameraData
        try {
            ArrayList<byte[]> dstPics = new ArrayList<>();
            ArrayList<String> fileNames = new ArrayList<>();

            JSONObject dstJson = new JSONObject();
            //String url = AdUtil.getCameraURL();

            //step 1 produce data
            dstJson.put("CamMAC", data.id);
            JSONArray dstData = new JSONArray();
            dstJson.put("CamData", dstData);


            JSONObject dstItem = new JSONObject();
            dstData.put(dstItem);
            dstItem.put("FaceID", data.id);
            dstItem.put("PicFormat", "JPG");
            if (data.gender == 1) {
                dstItem.put("Gender", "MALE");
            } else if (data.gender == 0) {
                dstItem.put("Gender", "FEMALE");
            }
            dstItem.put("Age", data.age);
            dstItem.put("FaceStatus", data.flag);
            dstItem.put("CreateTime", FANUtils.getBCDTime());
            fileNames.add("" + data.id);
            if (data.imageData != null && data.imageSize > 0) {
                dstPics.add(data.imageData);
            }

            //step 2 send data
            String user_msg = deviceSession.getUserRequest("PostCamData", dstJson);

            String uat_url = "http://noti2parser.uat.ffan.com/iot/v1/sadmcanface";
            FANIoTHttpChannel.getInstance().reportUserFile(uat_url, user_msg, fileNames, dstPics, callback);
        } catch (Exception e) {
            LOGGER.debug("sendCameraData " + e);
            e.printStackTrace();
        }
    }

    ////////////////////////////////////
    private void reportBeaconLog() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
        File f = new File("/home/chenyma/ws/temp/iot-java-sdk/example/beaconLog/beaconData");

        JSONObject params = new JSONObject();
        try {
            params.put("ProbeMAC", "DA-A1-19-B5-93-AA");
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        Callback cb = new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                LOGGER.error(e.toString());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    LOGGER.error(response.toString());
                    return;
                }

                beaconHasResponse = true;
                long time = System.currentTimeMillis();
                beaconSumSendTime = beaconSumSendTime + time - beaconSendSysTime;

                try {
                    String resp = response.body().string();
                    JSONObject json = new JSONObject(resp);
                    LOGGER.debug("recv response: " + json);
                    JSONObject result = json.getJSONObject("Result");
                    int code = result.getInt("Code");
                    if (code != 1000) {
                        LOGGER.error(response.toString());
                        return;
                    }

                } catch (Exception e) {
                    LOGGER.error(response.toString());
                    e.printStackTrace();
                }
            }
        };

        String msg = deviceSession.getUserRequest("PostProbeData", params);
        String url = "http://api.uat.ffan.com/iot/v1/sadmProbeData";
        LOGGER.debug("post beacon log to: " + url);

        if (beaconHasResponse == false) {
            // do not receive response
            beaconLostResponseTimes++;
            LOGGER.debug("<--- http lost sending Beacon response --->"); 
        }
        beaconSendTimes++;
        beaconHasResponse = false;
        LOGGER.debug("camLostResponseTimes: " + beaconLostResponseTimes + " camSendTimes: " + beaconSendTimes);

        FANIoTHttpChannel.getInstance().reportUserFile(url, msg, f, cb);                         
        beaconSendSysTime = System.currentTimeMillis();
                    } catch(Exception e) {

                    }
                }
            }).start();
    }

    private JSONArray getProbeData() {
        JSONArray devList = new JSONArray();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

        try {
            for (int i = 0; i < 70; i++) {
            	JSONObject item = new JSONObject();
            	item.put("RSSID",65);
                item.put("terminalMac", "DA-A1-19-B5-93-9D");
                item.put("inTime", "2017-10-31 15:18:53");
                item.put("outTime", "2017-10-31 15:18:53");
                devList.put(item);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return devList;
    }

    private void reportBeaconData() {
        JSONArray data = getProbeData();
        if (data == null) {
            //mFault.setFaultCode(PROBE_FAULT_NO_DATA);
            //mFault.setFaultName("无法获取探针数据");
            //reportFaultState();
            return;
        }

        try {
            JSONObject params = new JSONObject();
            //params.put("DevName", "FFAN_Probe");
            params.put("ProbeMAC", "DA-A1-19-B5-93-AA");
            params.put("ProbData", data);

            if (hasResponse == false) {
                // do not receive response
                lostResponseTimes++;
            }
            sendTimes++;
            hasResponse = false;


            deviceSession.reportDeviceMsg("PostProbeData", params);
            sendSysTime = System.currentTimeMillis();

            //mFault.setFaultCode(PROBE_FAULT_NORMAL);
            //mFault.setFaultName("探针正常");
            //reportFaultState();
        } catch (Exception e) {
            e.printStackTrace();
            //mFault.setFaultCode(PROBE_FAULT_REPORT);
            //mFault.setFaultName("无法上报探针数据");
            //reportFaultState();
        }
    }

    private JSONObject onUpdate() {
                try {
                    LOGGER.debug("SUBJECT_DEVICE_STATUS ");
                    //协议定义的请求Param参数
                    JSONObject params = new JSONObject();
                    JSONArray jsonArray = new JSONArray();
                    //广告机状态
                    JSONObject faultInfo = new JSONObject();
                    faultInfo.put("FaultCode", 0);
                    faultInfo.put("FaultName", "工作正常");
                    jsonArray.put(faultInfo);
                    //Probe状态
                    JSONObject probeInfo = new JSONObject();
                    probeInfo.put("FaultCode", "none");
                    probeInfo.put("FaultName", "ready");
                    jsonArray.put(probeInfo);
                    //Beacon状态
                    JSONObject beaconInfo = new JSONObject();
                    beaconInfo.put("FaultCode", "none");
                    beaconInfo.put("FaultName", "ready");
                    jsonArray.put(beaconInfo);
                    params.put("FaultInfoList", jsonArray);
                    params.put("DiskSpace", "8.00N");
                    //前台应用
                    params.put("RomAuth", 1);
                    params.put("AppPackName", "demoTest");
                    params.put("AppProcess", "demo");
                    params.put("WorkTime", 1000);
                    return params;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return null;
            }

    private void reportDeviceStatus() {
        try {
            JSONObject params = onUpdate();

                        if (hasResponse == false) {
                // do not receive response
                lostResponseTimes++;
            }
            sendTimes++;
            hasResponse = false;
            deviceSession.reportDeviceMsg("PostDevStatus", params);
            sendSysTime = System.currentTimeMillis();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveMqttTestLog() {
        if (sendTimes != lostResponseTimes) {
            long average = sumSendTime/(sendTimes - lostResponseTimes);
            ConfigUtilTest.setProperty(deviceMac + "_MqttAvgMs", String.format("%d", average));
        }

        if(sendTimes != 0) {
            float sendRate = (sendTimes - lostResponseTimes)/sendTimes;
            ConfigUtilTest.setProperty(deviceMac + "_MqttSusRate", String.format("%f", sendRate));
        }
    }

    private void saveHttpTestLog() {
        long camAverage  = 0;
        long beaconAverage = 0;
        long aTime = 0;
        if (camSendTimes != camLostResponseTimes) {
            camAverage = camSumSendTime/(camSendTimes - camLostResponseTimes);
        }
        if (beaconSendTimes != beaconLostResponseTimes) {
            beaconAverage = beaconSumSendTime/(beaconSendTimes - beaconLostResponseTimes);
        }
            
        aTime = (camAverage + beaconAverage)/2;
        ConfigUtilTest.setProperty(deviceMac + "_HttpAvgMs", String.format("%d", aTime));          

        if (camSendTimes != 0) {
            float camSendRate = (camSendTimes - camLostResponseTimes)/camSendTimes;
            ConfigUtilTest.setProperty(deviceMac + "_camHttpRate", String.format("%f", camSendRate));
        }
        if (beaconSendTimes != 0 ) {
            float beaconSendRate = (beaconSendTimes - beaconLostResponseTimes)/beaconSendTimes;
            ConfigUtilTest.setProperty(deviceMac + "_BeaconHttpRate", String.format("%f", beaconSendRate));
        }
        
        
    }


    @Override
    protected void finalize()
    {
        deviceIsReady = false;
        running = false;
        saveHttpTestLog();

        try {
            mIoTSDK.finalize();
            interrupt();
            join();
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }
    }

}
