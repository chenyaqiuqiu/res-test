package cn.wanda.demo;

import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.wanda.iotsdk.FANIoTProtocol;
import cn.wanda.iotsdk.FANUtils;
import cn.wanda.iotsdk.StringMD5;

public class DeviceProtocol extends FANIoTProtocol{
	private static final Logger LOGGER = Logger.getLogger(DeviceProtocol.class.getName());
	 //构造数据上报 
    public static JSONObject getPostDevDataRequest(String key, String target, String uuid,String mac, JSONArray devlist, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        JSONObject params = new JSONObject();
        JSONObject boxmac = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LogUtil.d("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
        	LOGGER.error(ex.toString());
        }
        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            
            boxmac.put("value", mac);
            params.put("BoxMAC", boxmac);
            params.put("ConnDevList", devlist);
             
            all.put("Params", params);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "PostDevData");
        } catch (JSONException ignored) {
        }

        LOGGER.debug("PostDevData req=" + all.toString());
        return all;
    }
    //构造状态上报
    public static JSONObject getPostDevStatusRequest(String key, String target, String uuid,String mac, int worktime, JSONArray faultinfolist, int msg_priority) {
        JSONObject all = new JSONObject();
        JSONObject request = new JSONObject();
        JSONObject system = new JSONObject();
        JSONObject params = new JSONObject();
        String now = FANUtils.getBCDTime();
        StringBuilder sb = new StringBuilder();
        sb.append("MsgPriority:");
        sb.append(msg_priority);
        sb.append(",RspID:0");
        sb.append(",Target:");
        sb.append(target);
        sb.append(",UUID:");
        sb.append(uuid);
        sb.append(",Time:");
        sb.append(now);
        sb.append(",Key:");
        sb.append(key);
       // LogUtil.d("sign_data: " + sb.toString());
        String md5_sign = "";
        try {
            md5_sign = StringMD5.getMD5(sb.toString()).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
        	LOGGER.error(ex.toString());
        }
        try {
            request.put("UUID", uuid);
            request.put("Target", target);
            request.put("MsgPriority", msg_priority);
            request.put("RspID", 0);
            system.put("ffanLink", DEFAULT_FFAN_LINK);
            system.put("Jsonrpc", DEFAULT_JSONRPC);
            system.put("Lang", DEFAULT_LANG);
            system.put("Sign", md5_sign);
            system.put("Key", key);
            system.put("Time", now);
            
            params.put("WorkTime", worktime);
            params.put("FaultInfoList", faultinfolist);
             
            all.put("Params", params);
            all.put("System", system);
            all.put("Request", request);
            all.put("Method", "PostDevStatus");
        } catch (JSONException ignored) {
        }

        LOGGER.debug("PostDevStatus req=" + all.toString());
        return all;
    }
    
    public static JSONArray getDefaultFaultInfoList()
    {
    	JSONArray ret = new JSONArray();
    	JSONObject fault = new JSONObject();
    	fault.put("FaultCode", 0);
    	fault.put("FaultName", "正常");
    	ret.put(fault);
    	return ret;
    }
}
