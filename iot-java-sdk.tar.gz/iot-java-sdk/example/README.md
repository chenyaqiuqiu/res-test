##########################################################

##########################################################
1. install iot-java-sdk to your repo (depend on maven)
2. how to package
	mvn package & mvn install
3. how to run
	java -jar target/demo-0.0.1.jar
	
